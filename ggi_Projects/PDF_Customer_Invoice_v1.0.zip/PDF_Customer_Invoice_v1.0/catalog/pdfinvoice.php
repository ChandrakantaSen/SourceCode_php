<?php
/*
  $Id: create_customer_pdf,v 1.0 2007/07/25 clefty (osc forum id chris23)

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
  
  Based on create_pdf , originally written by Neil Westlake (nwestlake@gmail.com
  
  Rewritten to display a PDF invoice for the customer to print / download within account_history_info.php
  
*/

 define('FPDF_FONTPATH','fpdf/font/');
 require('fpdf/fpdf.php');

 require('includes/application_top.php');
 require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_CUSTOMER_PDF);
 
 // function to return rgb value for fpdf from supplied hex (#abcdef)
 
 function html2rgb($color)
{
    if ($color[0] == '#')
        $color = substr($color, 1);

    if (strlen($color) == 6)
        list($r, $g, $b) = array($color[0].$color[1],
                                 $color[2].$color[3],
                                 $color[4].$color[5]);
    elseif (strlen($color) == 3)
        list($r, $g, $b) = array($color[0], $color[1], $color[2]);
    else
        return false;

    $r = hexdec($r); $g = hexdec($g); $b = hexdec($b);
    
    return array($r,$g,$b);
}

  $border_color = html2rgb(PDF_INV_BORDER_COLOR);
  $cell_color = html2rgb(PDF_INV_CELL_COLOR);
  $invoice_line = html2rgb(PDF_INV_INVLINE_COLOR);
  $highlight_color = html2rgb(PDF_INV_HIGHLIGHT_COLOR);
  $standard_color = html2rgb(PDF_INV_STANDARD_COLOR);
  $watermark_color = html2rgb(PDF_INV_WATERMARK_COLOR);
  
    
// perform security check to prevent "get" tampering to view other customer's invoices

  if (!tep_session_is_registered('customer_id')) {
    $navigation->set_snapshot();
    tep_redirect(tep_href_link(FILENAME_LOGIN, '', 'SSL'));
  }

  if (!isset($HTTP_GET_VARS['order_id']) || (isset($HTTP_GET_VARS['order_id']) && !is_numeric($HTTP_GET_VARS['order_id']))) {
    tep_redirect(tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'SSL'));
  }
  
  $customer_info_query = tep_db_query("select customers_id from " . TABLE_ORDERS . " where orders_id = '". (int)$HTTP_GET_VARS['order_id'] . "'");
  $customer_info = tep_db_fetch_array($customer_info_query);
  if ($customer_info['customers_id'] != $customer_id) {
    tep_redirect(tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'SSL'));
  }
  
  require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_ACCOUNT_HISTORY_INFO);

  require(DIR_WS_CLASSES . 'order.php');
  $order = new order($HTTP_GET_VARS['order_id']);

class PDF extends FPDF
{

//Page header
 function RoundedRect($x, $y, $w, $h,$r, $style = '')
    {
        $k = $this->k;
        $hp = $this->h;
        if($style=='F')
            $op='f';
        elseif($style=='FD' or $style=='DF')
            $op='B';
        else
            $op='S';
        $MyArc = 4/3 * (sqrt(2) - 1);
        $this->_out(sprintf('%.2f %.2f m',($x+$r)*$k,($hp-$y)*$k ));
        $xc = $x+$w-$r ;
        $yc = $y+$r;
        $this->_out(sprintf('%.2f %.2f l', $xc*$k,($hp-$y)*$k ));

        $this->_Arc($xc + $r*$MyArc, $yc - $r, $xc + $r, $yc - $r*$MyArc, $xc + $r, $yc);
        $xc = $x+$w-$r ;
        $yc = $y+$h-$r;
        $this->_out(sprintf('%.2f %.2f l',($x+$w)*$k,($hp-$yc)*$k));
        $this->_Arc($xc + $r, $yc + $r*$MyArc, $xc + $r*$MyArc, $yc + $r, $xc, $yc + $r);
        $xc = $x+$r ;
        $yc = $y+$h-$r;
        $this->_out(sprintf('%.2f %.2f l',$xc*$k,($hp-($y+$h))*$k));
        $this->_Arc($xc - $r*$MyArc, $yc + $r, $xc - $r, $yc + $r*$MyArc, $xc - $r, $yc);
        $xc = $x+$r ;
        $yc = $y+$r;
        $this->_out(sprintf('%.2f %.2f l',($x)*$k,($hp-$yc)*$k ));
        $this->_Arc($xc - $r, $yc - $r*$MyArc, $xc - $r*$MyArc, $yc - $r, $xc, $yc - $r);
        $this->_out($op);
    }

    function _Arc($x1, $y1, $x2, $y2, $x3, $y3)
    {
        $h = $this->h;
        $this->_out(sprintf('%.2f %.2f %.2f %.2f %.2f %.2f c ', $x1*$this->k, ($h-$y1)*$this->k,
            $x2*$this->k, ($h-$y2)*$this->k, $x3*$this->k, ($h-$y3)*$this->k));
    }
	
function Header()
{
    global $HTTP_GET_VARS, $highlight_color;
    $date = strftime('%A, %d %B %Y');
    
	//Logo
    $size =getimagesize(PDF_INVOICE_IMAGE);
    $this->Image(PDF_INVOICE_IMAGE,7,10,($size[0]*PDF_INV_IMG_CORRECTION),($size[1]*PDF_INV_IMG_CORRECTION),'', FILENAME_DEFAULT);

    // Invoice Number and date
	$this->SetFont(PDF_INV_CORE_FONT,'B',10);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
	$this->SetY(43);
	$this->MultiCell(100,6, PRINT_INVOICE_TITLE . (int)$HTTP_GET_VARS['order_id'] . "\n" . $date ,0,'L');
    
    // company name
	$this->SetX(0);
	$this->SetY(12);
    $this->SetFont(PDF_INV_CORE_FONT,'B',12);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
    $this->Ln(0);
    $this->Cell(149);
	$this->MultiCell(50, 3.5, STORE_NAME,0,'L'); 
    
	// Company Address
	$this->SetX(0);
	$this->SetY(16);
    $this->SetFont(PDF_INV_CORE_FONT,'B',10);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
    $this->Ln(0);
    $this->Cell(149);
	$this->MultiCell(50, 3.5, STORE_NAME_ADDRESS,0,'L'); 
	
	//email
	$this->SetX(0);
	$this->SetY(43);
	$this->SetFont(PDF_INV_CORE_FONT,'B',10);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
	$this->Ln(0);
    $this->Cell(88);
	$this->MultiCell(100, 6, "E-mail: " . STORE_OWNER_EMAIL_ADDRESS,0,'R');
	
	//website
	$this->SetX(0);
	$this->SetY(48);
	$this->SetFont(PDF_INV_CORE_FONT,'B',10);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
	$this->Ln(0);
    $this->Cell(88);
	$this->MultiCell(100, 6, "Web: " . HTTP_SERVER,0,'R');
    
    // VAT / Tax number (if enabled)
    if (DISPLAY_PDF_TAX_NUMBER == 'true'){
    $this->SetX(0);
	$this->SetY(53);
	$this->SetFont(PDF_INV_CORE_FONT,'B',10);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
	$this->Ln(0);
    $this->Cell(88);
	$this->MultiCell(100, 6, PDF_TAX_NAME . " " . PDF_TAX_NUMBER,0,'R');
   }
}

// function taken and modified from $Id: pdf_datasheet_functions v1.40 2005/06/16 13:46:29 ip chilipepper.it Exp $

  function RotatedText($x,$y,$txt,$angle)
 {
    //Text rotated around its origin
    $this->Rotate($angle,$x,$y);
    $this->Text($x,$y,$txt);
    $this->Rotate(0);
 }

 
 function Watermark()
 {
    global $watermark_color;
    $this->SetFont(PDF_INV_CORE_FONT,'B',60);
    $this->SetTextColor($watermark_color[0], $watermark_color[1], $watermark_color[2]);
    $ang=30;                                                                             
    $cos=cos(deg2rad($ang));
    $wwm=($this->GetStringWidth(PDF_INV_WATERMARK_TEXT)*$cos);
    $this->RotatedText(($this->w-$wwm)/2,$this->w,PDF_INV_WATERMARK_TEXT,$ang);
 }

function Footer()
{
    global $highlight_color, $invoice_line;
        
    // insert horiz line
    $this->SetY(-19);
    $this->SetDrawColor($invoice_line[0],$invoice_line[1],$invoice_line[2]);
    $this->Cell(198,.1,'',1,1,'L',1);
    
    //Position at 1.5 cm from bottom
    $this->SetY(-17);
    $this->SetFont(PDF_INV_CORE_FONT,'',8);
	$this->SetTextColor($highlight_color[0],$highlight_color[1],$highlight_color[2]);
	$this->Cell(0,10, PDF_INV_FOOTER_TEXT, 0,0,'C');
	}
}
//Instanciation of inherited class
$pdf=new PDF();

// Set the Page Margins
$pdf->SetMargins(6,2,6);

// Add the first page
$pdf->AddPage();


     // add watermark if required
     
    if(PDF_SHOW_WATERMARK == 'true'){
    $pdf->Watermark();
    }

//Draw the top line with invoice text
$pdf->Cell(50);
$pdf->SetY(60);
$pdf->SetDrawColor($invoice_line[0],$invoice_line[1],$invoice_line[2]);
$pdf->Cell(15,.1,'',1,1,'L',1);
$pdf->SetFont(PDF_INV_CORE_FONT,'BI',15);
$pdf->SetTextColor($invoice_line[0],$invoice_line[1],$invoice_line[2]);
$pdf->Text(22,61.5,'Invoice');
$pdf->SetY(60);
$pdf->SetDrawColor($invoice_line[0],$invoice_line[1],$invoice_line[2]);
$pdf->Cell(38);
$pdf->Cell(160,.1,'',1,1,'L',1);

//Draw Box for Invoice Address
$pdf->SetDrawColor($border_color[0],$border_color[1],$border_color[2]);
$pdf->SetLineWidth(0.2);
$pdf->SetFillColor($cell_color[0],$cell_color[1],$cell_color[2]);
$pdf->RoundedRect(6, 67, 90, 35, 2, 'DF');

//Draw the invoice address text
    $pdf->SetFont(PDF_INV_CORE_FONT,'B',10);
	$pdf->SetTextColor($standard_color[0],$standard_color[1],$standard_color[2]);
	$pdf->Text(11,77, ENTRY_SOLD_TO);
	$pdf->SetX(0);
	$pdf->SetY(80);
    $pdf->Cell(9);
	$pdf->MultiCell(70, 3.3, tep_address_format(1, $order->customer, '', '', "\n"),0,'L');
	
	//Draw Box for Delivery Address
	$pdf->SetDrawColor($border_color[0],$border_color[1],$border_color[2]);
	$pdf->SetLineWidth(0.2);
	$pdf->SetFillColor(255);
	$pdf->RoundedRect(108, 67, 90, 35, 2, 'DF');
	
	//Draw the invoice delivery address text
    $pdf->SetFont(PDF_INV_CORE_FONT,'B',10);
	$pdf->SetTextColor($standard_color[0],$standard_color[1],$standard_color[2]);
	$pdf->Text(113,77,ENTRY_SHIP_TO);
	$pdf->SetX(0);
	$pdf->SetY(80);
    $pdf->Cell(111);
	$pdf->MultiCell(70, 3.3, tep_address_format(1, $order->delivery, '', '', "\n"),0,'L');
	//Draw Box for Order Number, Date & Payment method
	$pdf->SetDrawColor($border_color[0],$border_color[1],$border_color[2]);
	$pdf->SetLineWidth(0.2);
	$pdf->SetFillColor($cell_color[0],$cell_color[1],$cell_color[2]);
	$pdf->RoundedRect(6, 107, 192, 11, 2, 'DF');

	//Draw Order Number Text
	$pdf->Text(10,113, PRINT_INVOICE_ORDERNR . (int)$HTTP_GET_VARS['order_id']);	
	//Draw Date of Order Text
	$pdf->Text(75,113, PRINT_INVOICE_DATE . tep_date_short($order->info['date_purchased']));	
	//Draw Payment Method Text
	$temp = substr ($order->info['payment_method'] , 0, 23);
	$pdf->Text(130,113, ENTRY_PAYMENT_METHOD . ' ' . $temp);	

//Fields Name position
$Y_Fields_Name_position = 125;
//Table position, under Fields Name
$Y_Table_Position = 131;


function output_table_heading($Y_Fields_Name_position){
    global  $pdf, $cell_color;
//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor($cell_color[0],$cell_color[1],$cell_color[2]);
//Bold Font for Field Name
$pdf->SetFont(PDF_INV_CORE_FONT,'B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(6);
$pdf->Cell(9,6,'Qty',1,0,'C',1);
$pdf->SetX(15);
$pdf->Cell(27,6,TABLE_HEADING_PRODUCTS_MODEL,1,0,'C',1);
$pdf->SetX(40);
$pdf->Cell(78,6,TABLE_HEADING_PRODUCTS,1,0,'C',1);
//$pdf->SetX(105);
//$pdf->Cell(15,6,TABLE_HEADING_TAX,1,0,'C',1);
$pdf->SetX(118);
$pdf->Cell(20,6,TABLE_HEADING_PRICE_EXCLUDING_TAX,1,0,'C',1);
$pdf->SetX(138);
$pdf->Cell(20,6,TABLE_HEADING_PRICE_INCLUDING_TAX,1,0,'C',1);
$pdf->SetX(158);
$pdf->Cell(20,6,TABLE_HEADING_TOTAL_EXCLUDING_TAX,1,0,'C',1);
$pdf->SetX(178);
$pdf->Cell(20,6,TABLE_HEADING_TOTAL_INCLUDING_TAX,1,0,'C',1);
$pdf->Ln();
}

output_table_heading($Y_Fields_Name_position);
//Show the products information line by line
for ($i = 0, $n = sizeof($order->products); $i < $n; $i++) {
	$pdf->SetFont(PDF_INV_CORE_FONT,'',10);
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(6);
	$pdf->MultiCell(9,6,$order->products[$i]['qty'],1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(40);
    
    $prod_attribs='';
        
    //get attribs and concat
        if ( (isset($order->products[$i]['attributes'])) && (sizeof($order->products[$i]['attributes']) > 0) ) {
        for ($j=0, $n2=sizeof($order->products[$i]['attributes']); $j<$n2; $j++) {
        $prod_attribs .= " - " .$order->products[$i]['attributes'][$j]['option'] . ': ' . $order->products[$i]['attributes'][$j]['value'];
        }
    }    
    
    $product_name_attrib_contact = $order->products[$i]['name'] . $prod_attribs;
    
	if (strlen($product_name_attrib_contact) > 40 && strlen($product_name_attrib_contact) < 50){
		$pdf->SetFont(PDF_INV_CORE_FONT,'',6);
		$pdf->MultiCell(78,6,$product_name_attrib_contact,1,'L');
		}

	else if (strlen($product_name_attrib_contact) > 50){
		$pdf->SetFont(PDF_INV_CORE_FONT,'',6);
		$pdf->MultiCell(78,6,substr($product_name_attrib_contact,0,60) ." .. ",1,'L');
		}
        
        
	else{
        $pdf->SetFont(PDF_INV_CORE_FONT,'',6);
		$pdf->MultiCell(78,6,$product_name_attrib_contact,1,'L');
        $pdf->Ln();
		}
        
	$pdf->SetFont(PDF_INV_CORE_FONT,'',10);
	//$pdf->SetY($Y_Table_Position);
	//$pdf->SetX(95);
	//$pdf->MultiCell(15,6,tep_display_tax_value($order->products[$i]['tax']) . '%',1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(15);
    $pdf->SetFont(PDF_INV_CORE_FONT,'',8);
	$pdf->MultiCell(25,6,$order->products[$i]['model'],1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(118);
    $pdf->SetFont(PDF_INV_CORE_FONT,'',10);
	$pdf->MultiCell(20,6,$currencies->format($order->products[$i]['final_price'], true, $order->info['currency'], $order->info['currency_value']),1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(138);
	$pdf->MultiCell(20,6,$currencies->format(tep_add_tax($order->products[$i]['final_price'], $order->products[$i]['tax']), true, $order->info['currency'], $order->info['currency_value']),1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(158);
	$pdf->MultiCell(20,6,$currencies->format($order->products[$i]['final_price'] * $order->products[$i]['qty'], true, $order->info['currency'], $order->info['currency_value']),1,'C');
	$pdf->SetY($Y_Table_Position);
	$pdf->SetX(178);
	$pdf->MultiCell(20,6,$currencies->format(tep_add_tax($order->products[$i]['final_price'], $order->products[$i]['tax']) * $order->products[$i]['qty'], true, $order->info['currency'], $order->info['currency_value']),1,'C');
	$Y_Table_Position += 6;

    //Check for product line overflow
     $item_count++;
    if ((is_long($item_count / 32) && $i >= 20) || ($i == 20)){
        $pdf->AddPage();
        //Fields Name position
        $Y_Fields_Name_position = 125;
        //Table position, under Fields Name
        $Y_Table_Position = 70;
        output_table_heading($Y_Table_Position-6);
        if ($i == 20) $item_count = 1;
    }
}
for ($i = 0, $n = sizeof($order->totals); $i < $n; $i++) {
	$pdf->SetY($Y_Table_Position + 5);
	$pdf->SetX(102);
	$temp = substr ($order->totals[$i]['text'],0 ,3);
	//if ($i == 3) $pdf->Text(10,10,$temp);
	if ($temp == '<b>')
		{
		$pdf->SetFont(PDF_INV_CORE_FONT,'B',10);
		$temp2 = substr($order->totals[$i]['text'], 3);
		$order->totals[$i]['text'] = substr($temp2, 0, strlen($temp2)-4);
		}
	$pdf->MultiCell(94,6,$order->totals[$i]['title'] . ' ' . $order->totals[$i]['text'],0,'R');
	$Y_Table_Position += 5;
}

     // set PDF metadata
     $pdf->SetTitle(PDF_META_TITLE);
     $pdf->SetSubject(PDF_META_SUBJECT . $HTTP_GET_VARS['order_id']);
     $pdf->SetAuthor(STORE_OWNER);
     
  	// PDF created

    function safe_filename ($filename) {
    $search = array(
    '/�/',
    '/�/','/�/',
    '/�/','/�/',
    '/�/','/�/',
    '([^[:alnum:]._])' 
    );
    $replace = array(
    'ss',
    'ae','Ae',
    'oe','Oe',
    'ue','Ue',
    '_'
    );
    
    // return a safe filename, lowercased and suffixed with invoice number.
    
    return strtolower(preg_replace($search,$replace,$filename));
}
    $file_name = safe_filename(STORE_NAME);
    $file_name .= "_invoice_" . $HTTP_GET_VARS['order_id'] . ".pdf";
    $mode = (FORCE_PDF_INVOICE_DOWNLOAD == 'true') ? 'D' : 'I';
    // what do we do? display inline or force download  
	$pdf->Output($file_name , $mode);
?>