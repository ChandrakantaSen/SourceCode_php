<?php
// customer pdf invoice

define('TABLE_HEADING_PRODUCTS_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_TAX', 'Tax');
define('TABLE_HEADING_TOTAL', 'Total');
define('TABLE_HEADING_PRICE_EXCLUDING_TAX', 'Price (ex)');
define('TABLE_HEADING_PRICE_INCLUDING_TAX', 'Price (inc)');
define('TABLE_HEADING_TOTAL_EXCLUDING_TAX', 'Total (ex)');
define('TABLE_HEADING_TOTAL_INCLUDING_TAX', 'Total (inc)');

define('ENTRY_SOLD_TO', 'Invoice to:');
define('ENTRY_SHIP_TO', 'Deliver to:');
define('ENTRY_PAYMENT_METHOD', 'Payment Method:');
define('ENTRY_SUB_TOTAL', 'Sub-Total:');
define('ENTRY_TAX', 'Tax:');
define('ENTRY_SHIPPING', 'Shipping:');
define('ENTRY_TOTAL', 'Total:');

define('PRINT_INVOICE_HEADING', 'Invoice');
define('PRINT_INVOICE_TEXT', 'Thank you for shopping at');
define('PRINT_INVOICE_TITLE', 'Invoice number: ');
define('PRINT_INVOICE_ORDERNR', 'Order number: ');
define('PRINT_INVOICE_DATE', 'Date of Order: ');

define ('PDF_META_TITLE','Your Invoice');
define ('PDF_META_SUBJECT','PDF copy of your invoice number: ');
   
?>