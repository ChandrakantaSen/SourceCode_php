PDF Customer Invoice v1.0
-------------------------

About
-----

This contribution will add a link to a customer's order history detail page (account_history_info.php) - see screeshot_client.gif. When clicked, this link
will generate a PDF copy invoice for the order.

There is a sample generated pdf (pdfinvoice.pdf) enclosed.

This contribution is based on PDF Invoice (http://www.oscommerce.com/community/contributions,3027) by Neil Westlake; kudos to him for the original PDF generation code.

Both contributions use Olivier Plathey's brilliant freeware FPDF class (http://fpdf.org)

Apart from recoding PDF Invoice to work client side, I have added the following features, configurable from within admin:

1. Font can be chosen - arial, times, courier, helvetica.

2. Colours for the invoice elements can be chosen. Hex values supplied are automatically converted to RGB as needed by FPDF so you can easily
match up your stylesheet.css colours to the invoice colours for a consistent look.

3. An optional watermark (text of your choice e.g. "Copy Invoice") can be added to the invoice.

4. An optional VAT tax reference can be added to the invoice.

5. Choice of displaying generated PDF inline or by forcing a download - set within admin configuration.

6. PDF Metadata (Store owner, Invoice number etc) is automatically added to the PDF.

7. Choice of store logos - png, gif, jpg.

8. Custom footer splash (marketing text) can be added.

9. Store logo size can be easily 'tweaked'.

The invoice will also display product attributes, if applicable (something which is missing from PDF Invoice)


Requirements
------------

Tested and works on PHP 5.2.1/MySQL 5.0.27 (Win32) and and PHP 4.4.6 / MySQL 4.1.21 (CentOS 4)

You will need PHP with GD GIF support enabled to use a GIF for your PDF store logo. If you don't have GD, just use a PNG or JPG for your logo.


Installation

------------

See installation.txt.


Instructions for use
--------------------

You should now have a new entry under configuration - PDF Invoices. The following explains how to use the options.

    OPTION                                          DEFAULT                     

1.  Choose logo  	                                images/sample_logo.png
2.  Choose an invoice font 	                        arial
3.  Do you want to display a VAT / Tax reference? 	false
4.  Set VAT / Tax number description 	            VAT number:
5.  Enter VAT / Tax number 	                        
6.  Force PDF download?                         	false 
7.  Do you want to display a text watermark?        false
8.  Set watermark text 	                            Copy Invoice
9.  Set PDF watermark colour 	                    #f3f3f3
10. Set PDF border colour 	                        #333333
11. Set PDF highlighted text colour 	            #cc0033
12. Set PDF cell fill colour 	                    #f3f3f3
13. Set PDF invoice line colour 	                #808080
14. Set PDF invoice standard text colour 	        #000000
15. Footer text 	                                Thank you for your purchase
16. Image correction factor 	                    0.18


1. Create a logo, maximum dimensions 600 x 180px. You can use jpg, gif or png. Transparency is supported for gif and png (but not alpha transparency. See 
Q & As below). Upload to your catalog/images directory. Set the path to images/your_image_name.(gif)(jpg)(png). A sample image is supplied. If your standard site logo fits the critera
for the pdf logo, you can of course use this.

If your image is too big or too small, you can fine-tune its size by changing the "Image correction factor" (see 16). The default of 0.18 is fine for a 600 x 180px image. Increase / decrease this value in 0.01 steps to increase / decrease image size respectively until you're happy.

2. Self-explanatory. If you want Courier, be aware that you may need to manually amend the font sizes for the product table header within catalog/pdfinvoice.php to ensure the text stays in the cells.

3. If you are required to show a Tax (VAT) number, choose true then set the tax description in (4) and enter your tax number in (5)

4. See 3.

5. See 3.

6. You have two methods of presenting the generated PDF to your customer. Inline - this is the default and will cause the PDF to open in their browser's PDF plug-in. If you choose "Force download", the customer will be presented with a "Download" dialogue. The "Save as" file name will be set to "yourstorename_invoice_x.pdf", where x is the order number. NB: this file name suggestion is ignored if the customer tries to save the document when viewing inline, instead the script filename is used i.e. pdfinvoice.pdf. This is a known issue with Adobe Reader and there is no apparent fix(?).

7. If you want to display a watermark through the invoice with some message e.g. "Copy Invoice", set this option to true, then set the wording you want in 8.

8. See 7.

[ 9 - 14 all deal with colours. You enter the required colour in hex format, with or without the leading #. ]

9. Keep the watermark colour pale!

10. Sets the border of the products table and the "Invoice to / Deliver to" boxes.

11. Sets the colour of: Invoice number, date, store address, web, email, VAT (tax) number & footer splash text.

12. Sets the fill colour for the product table heading cells and the background of the "Invoice to" box.

13. This sets the colour of the big italic invoice and its associated line and the line above the footer splash text.

14. Sets color of any text not in 11.

15. Sets the footer splash (marketing) text.

16. See 1.

It's probably an idea to just play around with the colours and see the effect it has on the PDF.


Q & As
------

Q. I'm getting "FPDF error: Alpha channel not supported: images/your_logo.png"

A. The FPDF class does NOT SUPPORT alpha transparency. Fix this by saving as PNG-8 (single channel transparency) or save your logo as a GIF / JPG

----------------------------------------------------------------------------------------------------------------------------------------------------

Q. The country name on the invoice is truncated eg United Kingdom says U

A. Not me! There was a change introduced in the latest MS2.2 version in catalog/includes/functions/general.php

FIND (around line 453):

$country = tep_output_string_protected($address['country']['title']);

REPLACE with:

$country = tep_output_string_protected($address['country']);

This will fix all instances of the truncated display on your site, not just in the PDF.

----------------------------------------------------------------------------------------------------------------------------------------------------

Q. I want to generate invoices from within admin.

A. Download PDF Invoice on which this contrib is based (http://www.oscommerce.com/community/contributions,3027). You can run this contribution along side it without any problems.

----------------------------------------------------------------------------------------------------------------------------------------------------

Q. I want to change the layout of the PDF, not just the colours. How do I do it?

A. Go to Olivier's site http://fpdf.org and have a look through the tutorials. Then start hacking away in pdfinvoice.php. It's well commented so you
can see what each block of code draws on the PDF. Please don't ask me to start designing custom layouts for you!

----------------------------------------------------------------------------------------------------------------------------------------------------

Language support
----------------

English provided. Other languages will need language entries for

catalog/includes/languages/account_history_info.php
catalog/includes/languages/pdfinvoice.php


Support
-------

Via the osC forums

I do check in regularly and try my very best to give quick support for any issues you may encounter.

Suggestions
-----------

I'm always happy to receive suggestions for improvements to this contribution. Most of the changes since the first release have been as a direct result of users wanting some new feature.

Licence
-------

Released under the GNU General Public License. See attached LICENSE file.