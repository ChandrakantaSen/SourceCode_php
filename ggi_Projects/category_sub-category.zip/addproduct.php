<?php
include('include/connect.php');


/*Adding Category Program*/
if(isset($_POST['addcat']))
	{
	$category=$_POST['catname'];
	
	if(empty($category))
		{
		echo "<script>window.alert('Field is empty');</script>";
		}
	else
	{
	$sql="select max(id) from maincategory";
	$result=mysql_query($sql);
	$max=mysql_result($result,0,0);
	$max=$max+1;
	
	
$sql="INSERT INTO maincategory values('$max','$category')";
$result=mysql_query($sql);
	echo "<script>window.alert('$category added successfully'); window.location='addproduct.php';</script>";
	}
	

	}/*ADDING CATEGORY PROGRAM ENDS HERE*/
	
/*ADDING SUB-CATEGORY PROGRAM STARTS HERE*/
if(isset($_POST['subcategory']))
{
	$cat=$_POST['category'];
	$subcat=$_POST['subcatname'];
	
	if(empty($subcat))
		{
		echo "<script>window.alert('Field is empty')</script>";
		}
	else
		{
		$sql="select max(id) from subcategory";
		$result=mysql_query($sql);
		$max=mysql_result($result,0,0);
		$max=$max+1;
	
	$sql="insert into subcategory values('$max','$subcat','$cat')";
	$result=mysql_query($sql);
	echo "<script>window.alert('$subcat added successfully');window.location='addproduct.php';</script>";
		}
}


/*ADDING SUB-CATEGORY PROGRAM ENDS HERE*/


/*ADDING PRODUCT PROGRAM STARTS HERE*/
if(isset($_POST['submit']))
	{
	$pname=$_POST['pname'];
	$cat=$_POST['pcategory'];
	$subcat=$_POST['subcat'];
	$desc=$_POST['description'];
			if(empty($pname))
				{
				echo "<script>window.alert('Product Name is empty');</script>";
				}
			if($cat=="select_category")
				{
				echo "<script>window.alert('Category is not selected');</script>";
				}
			if($sub="select_subcategory")
				{
				echo "<script>window.alert('Sub-Category is not selected');</script>";
				}
			
			else
			{
		

$sql="select max(id) from product";
$result=mysql_query($sql);
$max=mysql_result($result,0,0);
$max=$max+1;

$sql="insert into product values('$max','$pname','$subcat','$desc')";
mysql_query($sql);
			}
	
	}
/*ADDING PRODUCT PROGRAM ENDS HERE*/
?>
<style>
label
{
font-family:Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
color:#333333;
}
span
{
font-family:Verdana, Arial, Helvetica, sans-serif;
color:maroon;
font-size:10px;
cursor:pointer;
}
span a
{
font-family:Verdana, Arial, Helvetica, sans-serif;
color:#CCCCCC;
font-size:9px;
text-decoration:none;
}
span a:hover
{
color:#666666;
}
#frame
{
height:100%;
width:100%;
background-color:#000000;
position:absolute;
top:0px;
left:0px;
opacity:0.5;
filter:alpha(opacity=50);
-moz-opacity:0.5;
z-index:1001;

}
#addcat
{
background-color:white;
position:absolute;
top:70px;
left:70px;
display:none;
z-index:1002;
}
#addsubcat
{
top:70px;
left:70px;
background-color:white;
position:absolute;
display:none;
z-index:1003;
}
</style>
<div id="frame" style="display:none;">
</div>
<form name="addproducnt" method="post" enctype="multipart/form-data">
<table border="1" cellspacing="0">
<tr>
	<td><label for="name">Name:</label></td>
    <td><input type="text" name="pname" id="name"/></td>
</tr>

<tr>
	<td><label for="description">Description</label></td>
    <td><input type="text" name="description" id="description"/></td>
</tr>

<tr>
	<td><label for="category">Select Category</label>  </td>
	<td>
    <select name="pcategory">
   	
    	<?php

		$sql="select * from maincategory";
		$result=mysql_query($sql);
		while($rec=mysql_fetch_array($result))
			{
			
			$catid=$rec['id'];
			$cat=$rec['name'];
			
				
			echo "<option value='$catid' onChange='subcat()'>$cat</option>"; 

			}
		?>
		
    </select>
    <span><a href="#" onClick="javascript:document.getElementById('addcat').style.display='block'; document.getElementById('frame').style.display='block';">add category</a></span>
    </td>
</tr>

<tr>
	<td><label for="subcat">Select Sub Category</label></td>
    <td>
    <select name="subcat">
    
    	<?php
		
		
		$sql="select * from subcategory where cat_id='$catid'";
		$result=mysql_query($sql);
			while($rec=mysql_fetch_array($result))
				{
				
				$id=$rec['id'];
				$name=$rec['name'];
				$cat_id=$rec['cat_id'];
				
				if($id==$catid)
					{
					$sel="selected";
					}
				else
					{
					$sel="";
					}
				echo "<option value=$id>$name</option>";
					

				}
		?>
    </select>
    <span><a href="#" onClick="javascript:document.getElementById('addsubcat').style.display='block';document.getElementById('frame').style.display='block';">add sub-category</a></span>
    
    </td>
</tr>

<tr>
	
</tr>

<tr>
	<td colspan="2" align="center"><input type="submit" name="submit" value="Add Product"/></td>
</tr>
</table>
<br><br>
<!--ADDING SUB-CATEGORY END-->
<div id="addcat">

<table border="1" cellspacing="0">
<tr>
	<th colspan="2" align="center">Add Category</th></tr>
	<td><label for="catname">Category Name:</label></td>
	<td><input type="text" name="catname" id="catname"/></td>
</tr>

<tr>
	<td colspan="2" align="center">
    <input type="submit" name="addcat" value="Add Category"/>
        	<span onClick="javascript:document.getElementById('addcat').style.display='none';document.getElementById('frame').style.display='none';">Cancel</span>

    </td>
</tr>
</table>


</div>
<!--ADDING SUB-CATEGORY END-->


<!--ADDING SUB-CATEGORY START-->
<div id="addsubcat">
    	<table border="1" cellspacing="0">
        	<tr><th colspan="2">Sub Category</th></tr>
            <tr>
            	<td>
                <label for="cat">Salect Category</label>
                </td>
                <td>
                <select name="category">
                	<?php
					$sql="select * from maincategory";
					$result=mysql_query($sql);
						while($rec=mysql_fetch_array($result))
							{
							$id=$rec['id'];
							$cat=$rec['name'];
							
							echo "<option value='$id'>$cat</option>";
							}
					?>
                </select>
                </td>
            </tr>
            
            
        	<tr>
            	<td><label for="subcat">Add Sub Category</label></td>
				<td><input type="text" name="subcatname" id="subcat"></td>
            </tr>
            
            <tr>
			<td colspan="2" align="center"> <input type="submit" name="subcategory" value="Add Sub Category" /><span onClick="javascript:document.getElementById('frame').style.display='none';document.getElementById('addsubcat').style.display='none';">Cancel</span></td>
            </tr>
        </table>
    </div>
<!--ADDING SUB-CATEGORY END-->
</form>
