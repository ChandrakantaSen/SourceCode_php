# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: hct_test
# Domain name: hctrnd.com
# (c)2015 hctrnd.com
#
# Backup START time: 05:19:32
# Backup END time: 05:19:32
# Backup Date: 20 Nov 2015
 
drop table if exists `bank_detail`; 
CREATE TABLE `bank_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `account_no` int(11) DEFAULT NULL,
  `account_type` varchar(255) DEFAULT NULL,
  `credit_facility` int(2) DEFAULT NULL,
  `acc_opening_date` date DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('1', 'sbi', 'rubi', '1234', 'current', '0', '2015-07-29', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('2', '', '', '0', '', '0', '0000-00-00', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('4', 'sbi', 'rubi', '1234', 'salary', '0', '2015-08-04', '3');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('5', 'sadad', 'grgrew', '0', 'current', '0', '2015-01-19', '4');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('6', '', '', '0', '', '0', '0000-00-00', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('7', 'Krishanu Acharya', 'narendrapur', '2147483647', 'current', '0', '2015-08-10', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('8', '', '', '0', '', '0', '0000-00-00', '5');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('9', '', '', '0', '', '0', '0000-00-00', '5');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('18', 'sbi', 'rubi', '2147483647', 'current', '0', '2015-08-03', '15');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('19', '', '', '0', '', '0', '0000-00-00', '26');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('22', 'sbi', 'rubi', '2147483647', 'salary', '0', '2015-07-31', '15');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('23', '', '', '0', '', '0', '0000-00-00', '29');
 
drop table if exists `business_details`; 
CREATE TABLE `business_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `commence_date` date DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `sales` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `space_avail` varchar(255) DEFAULT NULL,
  `foundation` varchar(255) DEFAULT NULL,
  `cst_no` varchar(255) DEFAULT NULL,
  `cst_start_date` varchar(255) DEFAULT NULL,
  `vat_no` varchar(255) DEFAULT NULL,
  `vat_start_date` varchar(255) DEFAULT NULL,
  `trade_ref1` varchar(255) DEFAULT NULL,
  `trade_ref2` varchar(255) DEFAULT NULL,
  `turn_over1` varchar(255) DEFAULT NULL,
  `turn_over2` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('1', '2015-08-11', 'System Integrator', '10Crore/s', '20Crore/s', '30Crore/s', '650', 'Owned', '12345', '2015-07-29', '12345', '2015-07-27', 'hexcode', 'hct', '2013-2014,60Crore/s', '2012-2013,10laks.', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('2', '2015-08-10', 'Reseller', '10Crore/s', '10Crore/s', '10Crore/s', '650', 'Owned', '12345', '2015-07-28', '12345', '2015-07-26', 'hexcode', 'hct', '2013-2014,30Crore/s', '2012-2013,10laks.', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('3', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('5', '2015-07-27', 'System Integrator', '10Crore/s', '10Crore/s', '100Crore/s', '650', 'Owned', '12345', '2015-07-29', '12345', '2015-07-26', 'hexcode', 'hct', '2013-2014,120Crore/s', '2012-2013,10laks.', '3');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('6', '2013-10-02', 'Reseller,System Integrator', '12Lakh/s', '34Lakh/s', '5Lakh/s', '800', 'Rented', 'yttry5656565t', '2015-01-05', 'ytrytr65665', '2015-08-10', 'ttr', 'trertre', '2013-2014,51Lakh/s', '2012-2013,56', '4');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('7', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('8', '2015-08-10', 'Reseller,System Integrator', '10Crore/s', '10Crore/s', '10Crore/s', '650', 'Owned', '12345', '1998-05-05', '12345', '2015-08-10', 'hexcode', 'hct', '2013-2014,30Crore/s', '2012-2013,3', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('9', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '5');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('10', '0000-00-00', '', '10000000', '2000000', '3000000', '', 'Rented', '', '', '', '', '', '', '2013-2014,15000000', '2012-2013,', '5');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('19', '2015-08-18', 'System Integrator', '123456', '123456', '1254', '1235', 'Owned', '12345', '2015-07-28', '12345', '2015-08-02', 'hexcode', 'hct', '2013-2014,248166', '2012-2013,1232456', '15');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('20', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '26');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('23', '2015-07-27', 'System Integrator', '10Crore/s', '2000000Crore/s', '3000000Crore/s', '650', 'Owned', '12345', '2015-08-09', '12345', '2015-07-27', 'hexcode', 'hct', '2013-2014,5000010Crore/s', '2012-2013,123Crore/s', '15');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('24', '2015-08-18', 'Reseller,System Integrator', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '29');
 
drop table if exists `calendar_customer_details`; 
CREATE TABLE `calendar_customer_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) NOT NULL,
  `trading_address` varchar(255) NOT NULL,
  `registered_office` varchar(255) NOT NULL,
  `phone_number` int(10) NOT NULL,
  `fax_number` int(10) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `type_of_business` varchar(255) NOT NULL,
  `company_registration_number` varchar(255) NOT NULL,
  `vat_registration_number` varchar(18) NOT NULL,
  `number_of_years_trading` int(10) NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `owners_phone_numbers` int(10) NOT NULL,
  `company_credit_limit` int(11) NOT NULL,
  `company_needs` varchar(255) NOT NULL,
  `any_type_of_special_made_by_them` varchar(255) NOT NULL,
  `company_starts` date NOT NULL,
  `owner_date_of_birth` date NOT NULL,
  `owner_marrige_date` date NOT NULL,
  `no_of_employees` int(11) NOT NULL,
  `no_of_branches` int(11) NOT NULL,
  `pan_no` varchar(10) NOT NULL,
  `tin_no` int(11) NOT NULL,
  `tan_no` varchar(10) NOT NULL,
  `cst_no` varchar(7) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `business_name` (`business_name`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
insert into `calendar_customer_details` (`ID`, `business_name`, `trading_address`, `registered_office`, `phone_number`, `fax_number`, `email_address`, `type_of_business`, `company_registration_number`, `vat_registration_number`, `number_of_years_trading`, `owner_name`, `owners_phone_numbers`, `company_credit_limit`, `company_needs`, `any_type_of_special_made_by_them`, `company_starts`, `owner_date_of_birth`, `owner_marrige_date`, `no_of_employees`, `no_of_branches`, `pan_no`, `tin_no`, `tan_no`, `cst_no`, `status`) values ('6', 'Hexcode Technologies Pvt Ltd', 'airport', 'saltlake', '1234567890', '123456', 'info@hexcodetechnologies.com', 'Pvt Ltd', '12345678', '123456', '10', 'sdg', '1234567890', '2147483647', 'seo', 'No', '2015-01-05', '2015-11-04', '2015-01-14', '12', '2', '21342345', '1241235423', '2312341245', '1432145', '0');
insert into `calendar_customer_details` (`ID`, `business_name`, `trading_address`, `registered_office`, `phone_number`, `fax_number`, `email_address`, `type_of_business`, `company_registration_number`, `vat_registration_number`, `number_of_years_trading`, `owner_name`, `owners_phone_numbers`, `company_credit_limit`, `company_needs`, `any_type_of_special_made_by_them`, `company_starts`, `owner_date_of_birth`, `owner_marrige_date`, `no_of_employees`, `no_of_branches`, `pan_no`, `tin_no`, `tan_no`, `cst_no`, `status`) values ('7', '', '', '', '0', '0', '', '', '', '', '0', '', '0', '0', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0', '0', '', '0', '', '', '0');
insert into `calendar_customer_details` (`ID`, `business_name`, `trading_address`, `registered_office`, `phone_number`, `fax_number`, `email_address`, `type_of_business`, `company_registration_number`, `vat_registration_number`, `number_of_years_trading`, `owner_name`, `owners_phone_numbers`, `company_credit_limit`, `company_needs`, `any_type_of_special_made_by_them`, `company_starts`, `owner_date_of_birth`, `owner_marrige_date`, `no_of_employees`, `no_of_branches`, `pan_no`, `tin_no`, `tan_no`, `cst_no`, `status`) values ('8', 'intaxfin', 'airport', 'saltlake', '1234', '1234', 'info@intaxfin.com', 'Pvt Ltd', '1234', '111', '1', '12345', '12345', '1213', 'calender', 'No', '2015-11-19', '2015-11-01', '2015-11-20', '12', '22', '222', '12233', '123', '1222322', '0');
 
drop table if exists `calendar_holiday`; 
CREATE TABLE `calendar_holiday` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
insert into `calendar_holiday` (`id`, `date`, `description`) values ('2', '2015-12-25', 'Christmas');
insert into `calendar_holiday` (`id`, `date`, `description`) values ('6', '2016-01-26', 'Republic day');
 
drop table if exists `calendar_reg`; 
CREATE TABLE `calendar_reg` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `block` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('1', 'Super Admin', 'sdg', '123', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('2', 'Admin', 'manisankar', '1234', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('3', 'Manager', 'santanu', '12345', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('4', 'Sales Executive', 'vikash', '123456', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('5', 'Developer', 'vivek', '12345', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('6', 'Accountant', 'prasanta', '12345', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('7', 'Admin', '', '', '1');
 
drop table if exists `company_details`; 
CREATE TABLE `company_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `PIN` int(6) NOT NULL,
  `phone_no` varchar(13) NOT NULL,
  `mobile_no` varchar(13) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email_id` (`email_id`),
  UNIQUE KEY `mobile_no` (`mobile_no`),
  UNIQUE KEY `phone_no` (`phone_no`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('1', 'HexCode Technologies Pvt. Ltd.', '3g,Gour Sundar Seth Lane', 'kolkata', 'West Bengal', '700107', '03330112325', '7278935986', 'krishanurocks@gmail.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('3', 'IBM Kolkata', 'abc', 'kolkata', 'West Bengal', '721457', '123456789', '123456789', 'a@xyz.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('4', 'testing company', '4543rtrttr6trr', 'kolkata', 'West Bengal', '56465645', '54646464', '564646464', 'fdd@hgf.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('5', 'BGI', '', '', 'West Bengal', '0', '', '', '');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('15', 'xyza', 'barasat', 'kolkata', 'West Bengal', '700107', '1234567890123', '1234125478', '123@hotmail.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('26', 'Vivek', 'ddgfdgfdg5464fvbvgf fgdsgdfg3443vvbf', 'fdfgfdgfg', 'West Bengal', '4545', '4545', '454545', '4545@erew.yuyu');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('29', 'koushik & co.', 'FA-50, Radanga Main Road, K.M.C Ward No. 107', 'kolkata', 'West Bengal', '700107', '0332441139', '9831579115', 'diamondkaushik2017@gmail.com');
 
drop table if exists `company_sells`; 
CREATE TABLE `company_sells` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) DEFAULT NULL,
  `products` varchar(255) DEFAULT NULL,
  `qty_per_month` varchar(255) DEFAULT NULL,
  `value_per_month` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('1', '1', '1', '123', '12345', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('2', '1', '1', '30', '10', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('3', '1', '1', '', '', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('5', '1', '1', '123', '1000000', '3');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('6', '1', '1', '454', '4534', '4');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('7', '1', '1', '', '', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('8', '1', '1', '30', '10', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('9', '1', '1', '', '', '5');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('10', '1', '1', '', '', '5');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('19', '1', '1', '30', '12345', '15');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('20', '1', '1', 'ryery', 'eryeryrey', '26');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('23', '1', '1', '30', '12345', '15');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('24', '1', '1', '', '', '29');
 
drop table if exists `connections`; 
CREATE TABLE `connections` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('1', 'Krishanu Acharya', 'Proprietors', 'Barasat', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('2', 'Krishanu Acharya', 'Proprietors', 'FA-50 rajdanga road, near ruby, kolkata-700107', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('3', '', '', '', '', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('5', 'krishanu acharya', 'Directors', 'Barasat', '7278935986', '3');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('6', 'ttre', 'Proprietors', 'retert56 erye', '5646545', '4');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('7', '', '', '', '', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('8', 'krishanu', 'Proprietors', 'kolkata', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('9', '', '', '', '', '5');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('10', '', '', '', '', '5');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('19', 'gvhv', 'Proprietors', 'FA-50 rajdanga road, near ruby, kolkata-700107', '7278935986', '15');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('20', 'eryreye', 'Directors', 'ryeryreyreyery', 'eryeryeryery', '26');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('23', 'krishanu', 'Directors', 'kolkata', '7278935986', '15');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('24', '', '', '', '', '29');
 
drop table if exists `cust_lineup_items`; 
CREATE TABLE `cust_lineup_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lineup_items_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `delivery_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
insert into `cust_lineup_items` (`id`, `lineup_items_id`, `customer_id`, `delivery_date`) values ('2', '1', '6', '2015-11-21');
 
drop table if exists `customer_details`; 
CREATE TABLE `customer_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `no_of_customers` int(11) DEFAULT NULL,
  `no_of_outlets` int(11) DEFAULT NULL,
  `no_of_manpower` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('1', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('2', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('3', '0', '0', '0', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('5', '100', '3', '12', '3');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('6', '367', '2', '9', '4');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('7', '0', '0', '0', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('8', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('9', '0', '0', '0', '5');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('10', '0', '0', '0', '5');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('19', '35986', '3', '123', '15');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('20', '0', '0', '0', '26');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('23', '100', '3', '123', '15');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('24', '0', '0', '0', '29');
 
drop table if exists `line_up_items`; 
CREATE TABLE `line_up_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `req_days` int(11) NOT NULL,
  `item_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('3', 'Start of Project', '0', 'The day, when our accountant confirms, receipt of the entire payment. Our objective in selling you this service is not only to advise you what is best for your business, but also use or do it for yourself, on behalf of you, to get maximum mileage for your business, over a time span of one year. And hence, we need this calendar of events to be followed by all of us.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('5', 'Domain Registration For 1 Year', '3', 'This will be a new domain for new client, which the client can check via website at http://whois.icann.org/en (ICANN is a not-for-profit public-benefit corporation with participants from all over the world dedicated to keeping the Internet secure, stable and interoperable.) . Once you type in your confirmed domain name like intaxfin.com , you will be able to see that Hexcode Technologies (on behalf of you) is the owner of that new domain.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('6', 'Start of Project', '2', 'This will be a new domain for new client, which the client can check via website at http://whois.icann.org/en (ICANN is a not-for-profit public-benefit corporation with participants from all over the world dedicated to keeping the Internet secure, stable and interoperable.) . Once you type in your confirmed domain name like intaxfin.com , you will be able to see that Hexcode Technologies (on behalf of you) is the owner of that new domain. The client will get confirmation about their domain purchase, after the time elapsed with link to cross verify it.');
 
drop table if exists `phpjobscheduler`; 
CREATE TABLE `phpjobscheduler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scriptpath` varchar(255) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT '0',
  `time_last_fired` int(11) DEFAULT NULL,
  `run_only_once` tinyint(1) NOT NULL DEFAULT '0',
  `currently_running` tinyint(1) NOT NULL DEFAULT '0',
  `paused` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fire_time` (`fire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
insert into `phpjobscheduler` (`id`, `scriptpath`, `name`, `time_interval`, `fire_time`, `time_last_fired`, `run_only_once`, `currently_running`, `paused`) values ('3', 'http://hctrnd.com/phpmysqlautobackup/run.php', 'Email site stats to boss', '7200', '1447079158', '1447071958', '0', '0', '0');
 
drop table if exists `phpjobscheduler_logs`; 
CREATE TABLE `phpjobscheduler_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_added` int(11) DEFAULT NULL,
  `script` varchar(128) DEFAULT NULL,
  `output` text,
  `execution_time` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `phpjobscheduler_logs` (`id`, `date_added`, `script`, `output`, `execution_time`) values ('1', '1447072504', 'http://hctrnd.com/phpmysqlautobackup/run.php', '', '127.66990 seconds via PHP CURL ');
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1448014772');
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447072377', '29727', '135');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447073950', '30034', '137');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447130495', '30604', '143');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447134783', '30604', '143');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447307275', '30386', '126');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1448014613', '36317', '141');
 
drop table if exists `s_chat_messages`; 
CREATE TABLE `s_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `m_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('1', 'User1', 'hello', '1446118711');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('2', 'User2', 'hello...ki kobor?', '1446118783');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('3', 'User1', 'ei to cholche.. vai..', '1446118801');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('4', 'User2', 'popyeye er ki kobor?', '1446118874');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('5', 'User1', 'jiges kor ki bolche..', '1446118912');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('6', 'User3', 'hello', '1446118964');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('7', 'User3', 'hello sir', '1446118981');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('8', 'User2', 'hello...', '1446118990');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('9', 'User1', 'j jar nam ta plz bol.', '1446119004');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('10', 'User1', 'chandrakanta ki korchis/', '1446122467');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('11', 'User2', 'ki aar korbo?', '1446122514');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('12', 'User1', 'Kano kono kaj nei?', '1446122533');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('13', 'User2', 'excel korchi...', '1446122561');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('14', 'User2', 'excel korchi...', '1446124319');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('15', 'Chandrakanta', 'hello....', '1446190855');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('16', 'Krishanu', 'Ki korchis sobai?', '1446190905');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('17', 'Debashis', 'hi everybody..', '1446190909');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('18', 'Krishanu', 'Sobai ki korche?', '1446190977');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('19', 'Krishanu', 'hi', '1446191089');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('20', 'Krishanu', 'Hello', '1446191397');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('21', 'User1', 'Ki korchis sobai?', '1446191510');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('22', 'User1', '123', '1446191578');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('23', 'User1', '123', '1446191768');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('24', 'User1', 'kemon acho...bondhu?', '1446191906');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('25', 'Krishanu', 'Hi chandra', '1446192351');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('26', 'Chandrakanta', 'hello bhai...ki kobor?', '1446192370');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('27', 'Krishanu', 'ei badge print korte hobe..', '1446192388');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('28', 'Chandrakanta', 'kore phel...', '1446192430');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('29', 'Krishanu', 'sei to.', '1446192493');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('30', 'Debashis', 'bhalo aco sobai', '1446192706');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('31', 'Debashis', 'time not correct..pls check..', '1446192753');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('32', 'Krishanu', 'okay', '1446196174');
 
drop table if exists `supplier_details`; 
CREATE TABLE `supplier_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('1', 'Krishanu Acharya', 'Barasat', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('2', 'Arindam Pal', 'FA-50 rajdanga road, near ruby, kolkata-700107', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('3', '', '', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('5', 'Arindam Pal', 'Barasat', '3');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('6', 'rtyrete', 'retert56 erye', '4');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('7', '', '', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('8', 'Arindam Pal', 'kolkata', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('9', '', '', '5');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('10', '', '', '5');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('19', 'Krishanu Acharya', 'FA-50 rajdanga road, near ruby, kolkata-700107', '15');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('20', 'etrerytr', 'ryeryreyreyery', '26');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('23', 'Arindam Pal', 'kolkata', '15');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('24', '', '', '29');

ALTER TABLE `bank_detail` ADD   CONSTRAINT `bank_detail_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `business_details` ADD   CONSTRAINT `business_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `company_sells` ADD   CONSTRAINT `company_sells_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `connections` ADD   CONSTRAINT `connections_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `customer_details` ADD   CONSTRAINT `customer_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `supplier_details` ADD   CONSTRAINT `supplier_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);
