# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: hct_test
# Domain name: hctrnd.com
# (c)2015 hctrnd.com
#
# Backup START time: 00:45:28
# Backup END time: 00:45:28
# Backup Date: 04 Dec 2015
 
drop table if exists `bank_detail`; 
CREATE TABLE `bank_detail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `account_no` int(11) DEFAULT NULL,
  `account_type` varchar(255) DEFAULT NULL,
  `credit_facility` int(2) DEFAULT NULL,
  `acc_opening_date` date DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('1', 'sbi', 'rubi', '1234', 'current', '0', '2015-07-29', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('2', '', '', '0', '', '0', '0000-00-00', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('4', 'sbi', 'rubi', '1234', 'salary', '0', '2015-08-04', '3');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('5', 'sadad', 'grgrew', '0', 'current', '0', '2015-01-19', '4');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('6', '', '', '0', '', '0', '0000-00-00', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('7', 'Krishanu Acharya', 'narendrapur', '2147483647', 'current', '0', '2015-08-10', '1');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('8', '', '', '0', '', '0', '0000-00-00', '5');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('9', '', '', '0', '', '0', '0000-00-00', '5');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('18', 'sbi', 'rubi', '2147483647', 'current', '0', '2015-08-03', '15');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('19', '', '', '0', '', '0', '0000-00-00', '26');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('22', 'sbi', 'rubi', '2147483647', 'salary', '0', '2015-07-31', '15');
insert into `bank_detail` (`ID`, `bank_name`, `branch_name`, `account_no`, `account_type`, `credit_facility`, `acc_opening_date`, `company_id`) values ('23', '', '', '0', '', '0', '0000-00-00', '29');
 
drop table if exists `business_details`; 
CREATE TABLE `business_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `commence_date` date DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `sales` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `space_avail` varchar(255) DEFAULT NULL,
  `foundation` varchar(255) DEFAULT NULL,
  `cst_no` varchar(255) DEFAULT NULL,
  `cst_start_date` varchar(255) DEFAULT NULL,
  `vat_no` varchar(255) DEFAULT NULL,
  `vat_start_date` varchar(255) DEFAULT NULL,
  `trade_ref1` varchar(255) DEFAULT NULL,
  `trade_ref2` varchar(255) DEFAULT NULL,
  `turn_over1` varchar(255) DEFAULT NULL,
  `turn_over2` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('1', '2015-08-11', 'System Integrator', '10Crore/s', '20Crore/s', '30Crore/s', '650', 'Owned', '12345', '2015-07-29', '12345', '2015-07-27', 'hexcode', 'hct', '2013-2014,60Crore/s', '2012-2013,10laks.', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('2', '2015-08-10', 'Reseller', '10Crore/s', '10Crore/s', '10Crore/s', '650', 'Owned', '12345', '2015-07-28', '12345', '2015-07-26', 'hexcode', 'hct', '2013-2014,30Crore/s', '2012-2013,10laks.', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('3', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('5', '2015-07-27', 'System Integrator', '10Crore/s', '10Crore/s', '100Crore/s', '650', 'Owned', '12345', '2015-07-29', '12345', '2015-07-26', 'hexcode', 'hct', '2013-2014,120Crore/s', '2012-2013,10laks.', '3');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('6', '2013-10-02', 'Reseller,System Integrator', '12Lakh/s', '34Lakh/s', '5Lakh/s', '800', 'Rented', 'yttry5656565t', '2015-01-05', 'ytrytr65665', '2015-08-10', 'ttr', 'trertre', '2013-2014,51Lakh/s', '2012-2013,56', '4');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('7', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('8', '2015-08-10', 'Reseller,System Integrator', '10Crore/s', '10Crore/s', '10Crore/s', '650', 'Owned', '12345', '1998-05-05', '12345', '2015-08-10', 'hexcode', 'hct', '2013-2014,30Crore/s', '2012-2013,3', '1');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('9', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '5');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('10', '0000-00-00', '', '10000000', '2000000', '3000000', '', 'Rented', '', '', '', '', '', '', '2013-2014,15000000', '2012-2013,', '5');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('19', '2015-08-18', 'System Integrator', '123456', '123456', '1254', '1235', 'Owned', '12345', '2015-07-28', '12345', '2015-08-02', 'hexcode', 'hct', '2013-2014,248166', '2012-2013,1232456', '15');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('20', '0000-00-00', '', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '26');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('23', '2015-07-27', 'System Integrator', '10Crore/s', '2000000Crore/s', '3000000Crore/s', '650', 'Owned', '12345', '2015-08-09', '12345', '2015-07-27', 'hexcode', 'hct', '2013-2014,5000010Crore/s', '2012-2013,123Crore/s', '15');
insert into `business_details` (`ID`, `commence_date`, `category`, `sales`, `service`, `others`, `space_avail`, `foundation`, `cst_no`, `cst_start_date`, `vat_no`, `vat_start_date`, `trade_ref1`, `trade_ref2`, `turn_over1`, `turn_over2`, `company_id`) values ('24', '2015-08-18', 'Reseller,System Integrator', '', '', '', '', 'Rented', '', '', '', '', '', '', '2013-2014,', '2012-2013,', '29');
 
drop table if exists `calendar_customer_details`; 
CREATE TABLE `calendar_customer_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) NOT NULL,
  `trading_address` varchar(255) NOT NULL,
  `registered_office` varchar(255) NOT NULL,
  `phone_number` int(10) NOT NULL,
  `fax_number` int(10) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `type_of_business` varchar(255) NOT NULL,
  `company_registration_number` varchar(255) NOT NULL,
  `vat_registration_number` varchar(18) NOT NULL,
  `number_of_years_trading` int(10) NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `owners_phone_numbers` int(10) NOT NULL,
  `company_credit_limit` int(11) NOT NULL,
  `company_needs` varchar(255) NOT NULL,
  `any_type_of_special_made_by_them` varchar(255) NOT NULL,
  `company_starts` date NOT NULL,
  `owner_date_of_birth` date NOT NULL,
  `owner_marrige_date` date NOT NULL,
  `no_of_employees` int(11) NOT NULL,
  `no_of_branches` int(11) NOT NULL,
  `pan_no` varchar(10) NOT NULL,
  `tin_no` int(11) NOT NULL,
  `tan_no` varchar(10) NOT NULL,
  `cst_no` varchar(7) NOT NULL,
  `status` int(1) NOT NULL,
  `calendar_file` varchar(255) NOT NULL,
  `vertical_type` varchar(255) NOT NULL,
  `template_name` varchar(255) NOT NULL,
  `site_path` varchar(255) NOT NULL,
  `confirmation` int(2) NOT NULL,
  `close_date` date NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `business_name` (`business_name`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
insert into `calendar_customer_details` (`ID`, `business_name`, `trading_address`, `registered_office`, `phone_number`, `fax_number`, `email_address`, `type_of_business`, `company_registration_number`, `vat_registration_number`, `number_of_years_trading`, `owner_name`, `owners_phone_numbers`, `company_credit_limit`, `company_needs`, `any_type_of_special_made_by_them`, `company_starts`, `owner_date_of_birth`, `owner_marrige_date`, `no_of_employees`, `no_of_branches`, `pan_no`, `tin_no`, `tan_no`, `cst_no`, `status`, `calendar_file`, `vertical_type`, `template_name`, `site_path`, `confirmation`, `close_date`) values ('6', 'Hexcode Technologies Pvt Ltd', 'airport', 'saltlake', '1234567890', '123456', 'info@hexcodetechnologies.com', 'Pvt Ltd', '12345678', '123456', '10', 'sdg', '1234567890', '2147483647', 'seo', 'No', '2015-01-05', '2015-11-04', '2015-01-14', '12', '2', '21342345', '1241235423', '2312341245', '1432145', '1', '', 'Garment Shop', 'http://hctrnd.com/Calendar/vertical_template/Garment Shop/garment_shop1/', 'http://hctrnd.com/Calendar/hexcode_technologies_pvt_ltd/', '1', '2015-11-26');
insert into `calendar_customer_details` (`ID`, `business_name`, `trading_address`, `registered_office`, `phone_number`, `fax_number`, `email_address`, `type_of_business`, `company_registration_number`, `vat_registration_number`, `number_of_years_trading`, `owner_name`, `owners_phone_numbers`, `company_credit_limit`, `company_needs`, `any_type_of_special_made_by_them`, `company_starts`, `owner_date_of_birth`, `owner_marrige_date`, `no_of_employees`, `no_of_branches`, `pan_no`, `tin_no`, `tan_no`, `cst_no`, `status`, `calendar_file`, `vertical_type`, `template_name`, `site_path`, `confirmation`, `close_date`) values ('8', 'intaxfin', 'airport', 'saltlake', '1234', '1234', 'info@intaxfin.com', 'Pvt Ltd', '1234', '111', '1', '12345', '12345', '1213', 'calender', 'No', '2015-11-19', '2015-11-01', '2015-11-20', '12', '22', '222', '12233', '123', '1222322', '0', 'upload/1448275797_65580_logo.jpg', '', '', '', '0', '0000-00-00');
 
drop table if exists `calendar_holiday`; 
CREATE TABLE `calendar_holiday` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
insert into `calendar_holiday` (`id`, `date`, `description`) values ('2', '2015-12-25', 'Christmas');
insert into `calendar_holiday` (`id`, `date`, `description`) values ('6', '2016-01-26', 'Republic day');
 
drop table if exists `calendar_reg`; 
CREATE TABLE `calendar_reg` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `block` int(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('1', 'Super Admin', 'sdg', '123', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('2', 'Admin', 'manisankar', '1234', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('3', 'Manager', 'santanu', '12345', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('4', 'Sales Executive', 'vikash', '123456', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('5', 'Developer', 'vivek', '12345', '0');
insert into `calendar_reg` (`id`, `type`, `email`, `pwd`, `block`) values ('6', 'Accountant', 'prasanta', '12345', '0');
 
drop table if exists `company_details`; 
CREATE TABLE `company_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `PIN` int(6) NOT NULL,
  `phone_no` varchar(13) NOT NULL,
  `mobile_no` varchar(13) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email_id` (`email_id`),
  UNIQUE KEY `mobile_no` (`mobile_no`),
  UNIQUE KEY `phone_no` (`phone_no`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('1', 'HexCode Technologies Pvt. Ltd.', '3g,Gour Sundar Seth Lane', 'kolkata', 'West Bengal', '700107', '03330112325', '7278935986', 'krishanurocks@gmail.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('3', 'IBM Kolkata', 'abc', 'kolkata', 'West Bengal', '721457', '123456789', '123456789', 'a@xyz.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('4', 'testing company', '4543rtrttr6trr', 'kolkata', 'West Bengal', '56465645', '54646464', '564646464', 'fdd@hgf.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('5', 'BGI', '', '', 'West Bengal', '0', '', '', '');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('15', 'xyza', 'barasat', 'kolkata', 'West Bengal', '700107', '1234567890123', '1234125478', '123@hotmail.com');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('26', 'Vivek', 'ddgfdgfdg5464fvbvgf fgdsgdfg3443vvbf', 'fdfgfdgfg', 'West Bengal', '4545', '4545', '454545', '4545@erew.yuyu');
insert into `company_details` (`ID`, `name`, `address`, `city`, `state`, `PIN`, `phone_no`, `mobile_no`, `email_id`) values ('29', 'koushik & co.', 'FA-50, Radanga Main Road, K.M.C Ward No. 107', 'kolkata', 'West Bengal', '700107', '0332441139', '9831579115', 'diamondkaushik2017@gmail.com');
 
drop table if exists `company_sells`; 
CREATE TABLE `company_sells` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) DEFAULT NULL,
  `products` varchar(255) DEFAULT NULL,
  `qty_per_month` varchar(255) DEFAULT NULL,
  `value_per_month` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('1', '1', '1', '123', '12345', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('2', '1', '1', '30', '10', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('3', '1', '1', '', '', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('5', '1', '1', '123', '1000000', '3');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('6', '1', '1', '454', '4534', '4');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('7', '1', '1', '', '', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('8', '1', '1', '30', '10', '1');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('9', '1', '1', '', '', '5');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('10', '1', '1', '', '', '5');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('19', '1', '1', '30', '12345', '15');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('20', '1', '1', 'ryery', 'eryeryrey', '26');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('23', '1', '1', '30', '12345', '15');
insert into `company_sells` (`ID`, `brand`, `products`, `qty_per_month`, `value_per_month`, `company_id`) values ('24', '1', '1', '', '', '29');
 
drop table if exists `connections`; 
CREATE TABLE `connections` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('1', 'Krishanu Acharya', 'Proprietors', 'Barasat', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('2', 'Krishanu Acharya', 'Proprietors', 'FA-50 rajdanga road, near ruby, kolkata-700107', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('3', '', '', '', '', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('5', 'krishanu acharya', 'Directors', 'Barasat', '7278935986', '3');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('6', 'ttre', 'Proprietors', 'retert56 erye', '5646545', '4');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('7', '', '', '', '', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('8', 'krishanu', 'Proprietors', 'kolkata', '7278935986', '1');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('9', '', '', '', '', '5');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('10', '', '', '', '', '5');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('19', 'gvhv', 'Proprietors', 'FA-50 rajdanga road, near ruby, kolkata-700107', '7278935986', '15');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('20', 'eryreye', 'Directors', 'ryeryreyreyery', 'eryeryeryery', '26');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('23', 'krishanu', 'Directors', 'kolkata', '7278935986', '15');
insert into `connections` (`ID`, `name`, `type`, `address`, `phone_no`, `company_id`) values ('24', '', '', '', '', '29');
 
drop table if exists `cust_lineup_items`; 
CREATE TABLE `cust_lineup_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lineup_items_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `delivery_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
insert into `cust_lineup_items` (`id`, `lineup_items_id`, `customer_id`, `delivery_date`) values ('13', '17', '6', '2015-11-30');
insert into `cust_lineup_items` (`id`, `lineup_items_id`, `customer_id`, `delivery_date`) values ('14', '18', '6', '2015-11-30');
insert into `cust_lineup_items` (`id`, `lineup_items_id`, `customer_id`, `delivery_date`) values ('15', '21', '6', '2015-12-03');
insert into `cust_lineup_items` (`id`, `lineup_items_id`, `customer_id`, `delivery_date`) values ('16', '26', '6', '2015-12-08');
 
drop table if exists `customer_details`; 
CREATE TABLE `customer_details` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `no_of_customers` int(11) DEFAULT NULL,
  `no_of_outlets` int(11) DEFAULT NULL,
  `no_of_manpower` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('1', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('2', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('3', '0', '0', '0', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('5', '100', '3', '12', '3');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('6', '367', '2', '9', '4');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('7', '0', '0', '0', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('8', '100', '3', '12', '1');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('9', '0', '0', '0', '5');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('10', '0', '0', '0', '5');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('19', '35986', '3', '123', '15');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('20', '0', '0', '0', '26');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('23', '100', '3', '123', '15');
insert into `customer_details` (`ID`, `no_of_customers`, `no_of_outlets`, `no_of_manpower`, `company_id`) values ('24', '0', '0', '0', '29');
 
drop table if exists `line_up_items`; 
CREATE TABLE `line_up_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `req_days` int(11) NOT NULL,
  `item_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('16', 'Start of Project', '0', 'The day, when our accountant confirms, receipt of the entire payment. Our objective in selling you this service is not only to advise you what is best for your business, but also use or do it for yourself, on behalf of you, to get maximum mileage for your business, over a time span of one year. And hence, we need this calendar of events to be followed by all of us.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('17', 'Domain Registration For 1 Year', '3', 'This will be a new domain for new client, which the client can check via website at http://whois.icann.org/en (ICANN is a not-for-profit public-benefit corporation with participants from all over the world dedicated to keeping the Internet secure, stable and interoperable.) . Once you type in your confirmed domain name like intaxfin.com , you will be able to see that Hexcode Technologies (on behalf of you) is the owner of that new domain. The client will get confirmation about their domain purchase, after the time elapsed with link to cross verify it. As it is extremely crucial for us to ensure the continuous business flow for our customers, we do not allow our work to be hosted on someone else\"s server or site. If you have an existing site, you can setup a small link to the new site (hosted on our server), which can be entirely managed by us.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('18', 'Web mail + pop3 E-mail', '3', 'Web mail will allow you to see your mails from any standard computer or mobile or device equipped with a standard browser, with an active Internet connection, irrespective of whether its properly configured for your own mails or not. POP Mail (Post office protocol) will allow you to configure these mails in your mobile or computer, where it can automatically download your mails and save them for you to see and work on them, even when you do not have any active internet connection. Normally all of the enterprises uses this kind of mail, to keep them aware about the latest happening, as it do not depend on when you open to see them, but it download the mails at a minimal interval of time (provided its connected with the Internet during that time).');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('19', '10 E-mail account allowed', '5', 'These are the most vital business email ids, that you will need to make your business look like a real enterprise business. Example email ids will be webmaster@yourdomain.com, support@yourdomain.com, sales@yourdomain.com, feedback@yourdomain.com, yourname@yourdomain.com, CEO@yourdomain.com, facebook@yourdomain.com, Accounts@yourdomain.com, HR_manager@yourdomain.com etc.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('20', 'Hosting of your Major site for 1 year', '6', 'Your domain www.yourdomain.com will show its under construction, after we confirm you the domain purchased, and the time is elapsed.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('21', 'Server up-time 99.9%', '6', 'This is what we promise and this includes 24X7X365 days and hours. This actually means, out of 365 days X 24 hours = 8760 hours, our server should be up and running for at least 8760 hours X 99.9% = 8751 hours in a year. This is what we strive to attain.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('22', 'Eye-catching crystal clear graphics', '6', 'Your website will be watched by millions of visitors worldwide and hence, it needs to have eye-catching pictures and photographs. Hence we like you to get us customized photographs of your business and we will add our own eye catching standard graphics to combine with it.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('23', 'Unique under construction website template for your business', '7', 'We will develop one UNIQUE under-construction page, using your business logo and it won\"t be the standard page for your business, which will basically show to the world, that you have a large team to work from behind just like an enterprise..');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('24', 'Google adwords Planning, Budgeting and Analysis #1', '7', 'AdWords (Google AdWords) is an advertising service by Google for businesses wanting to display ads on Google and its advertising network. The AdWords program enables businesses to set a budget for advertising and only pay when people click the ads. The ad service is largely focused on keywords. These keywords will be carefully selected by our consultants, after consulting google supplied previous month database for similar industry (where your business exists) and create unique landing page for you, so that you can compete effectively with your known competitors. This is way different than normal SEO consulting, where people try to sell you their similar services, based on their intuitions. For example, if you have a Gold Jewellery shop, our consultants will collect data from Google about \"what is searched mostly in your industry, last month\" and not go by common intuition that people searched only for \"best Jewellery shop\" like phrase. We found that people looked for \"XYZ Jewellery shop\" more and hence, we suggested that your business should have a landing page from google adwords, comparing why people should buy from you, rather than \"XYZ jewellery shop\" with possible rebate in your \"making charge\" component, using unique code, generated by our server. ');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('25', 'Facebook Advt. Planning #1', '7', 'Location - Reach your customers in the areas where they live or where they do business with you. Target adverts by country, county/region, postcode or even the area around your business. Demographics - The customers your business serves are on Facebook. Choose the audiences that should see your adverts by age, gender, interests and even the languages they speak. Interests - When people are interested in your business, they are more likely to take action on your advert. Choose from hundreds of categories such as music, films, sport, games, shopping and so much more to help you find just the right people.  Behaviours - You know your customers best, and you can find them based on the things they do â€“ such as shopping behaviour, the type of phone they use or if they are looking to buy a car or house. Connections - Reach the people who like your Page or your app â€“ and reach their friends, too. It is an easy way to find even more people who may be interested in your business. Let\"s say that your would be customer is thinking about buying a new TV, and he start researching TVs on the web and in mobile apps. Based on this activity, Facebook may show  ads for deals on a TV to help him get the best price or other brands to consider. And because Facebook think he is interested in electronics, Facebook may show him ads for other electronics in the future, like speakers or a game console to go with his new TV.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('26', 'Business Consulting Meeting, planning and calendaring of events #1', '10', 'This calendar will be prepared after our business consultants sit with you and find out your dreams and wish list and will try to get you a objective driven plan for the year, which will be updated, after every quarter, depending on how the business is running, after following his advice. This ideally should contain 4 annual promotions and overall marketing and sales strategy. For marketing advertisements (advt. cost will be optional and additional) our business consultants are equipped with the information, about which newspaper, or airline in-flight magazine or periodicals or hoardings  advt. can get you optimum marketing advantage. So, it is not a intuition based marketing decision, rather backed by suitable information. He will also be able to use your core skills, to advance your business goals. May be you are a very good salesman from a tour and travel company and can sell your packages, using stories about your own visit to those places. Our biz. consultant will be able to utilize your that skill, to sell your packages too, using them as different web pages.  As human resource could also be an integrated component to your business, you will also be advised about how to proceed on HR recruitment, motivation and management.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('27', 'Hosting your mobile site', '20', 'Your domain m.yourdomain.com will show its under construction, after we confirm you the domain purchased, and the time is elapsed.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('28', 'W3C markup vapdation', '21', 'World Wide Web Consortium validator (not a part of Hexcode Technologies Company), maintained at W3C by W3C staff and collaborators. Checks the markup validity of Web documents in HTML, XHTML etc. Most pages on the World Wide Web are written in computer languages (such as HTML) that allow Web authors to structure text, add multimedia content, and specify what appearance, or style, the result should have. As for every language, these have their own grammar, vocabulary and syntax, and every document written with these computer languages are supposed to follow these rules. The (X)HTML languages, for all versions up to XHTML 1.1, are using machine-readable grammars called DTDs, a mechanism inherited from SGML. However, Just as texts in a natural language can include spelling or grammar errors, documents using Markup languages may (for various reasons) not be following these rules. The process of verifying whether a document actually follows the rules for the language(s) it uses is called validation, and the tool used for that is a validator. A document that passes this process with success is called valid. ');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('30', 'Mobile responsive site creation#1', '25', 'Nowadays people watch Internet pages on different devices and most of them are being seen on mobile devices like smart phone, Ipads, Iphone etc. with varying screen size and low bandwidth based internet access plans combination. Hence, we will need to identify who is seeing from which device and dynamically (means automatically, without any human intervention) need to redirect them to our newly created mobile site, which will have low pixel based photographs and low bandwidth compatible site, which can adjust the screen sizes according to the viewing devices. This will have most of the major features available on your main site but will be optimized for low bandwidth and varying screen sized (mostly smaller than PCs) devices.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('31', 'Glossy navigation bar', '30', 'A navigation bar (or navigation system) is a section of a graphical user interface intended to aid visitors in accessing information. Navigation bars are implemented in file browsers, web browsers and as a design element of our web sites.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('32', 'Fully functional contact-us form', '30', 'In the entire World Wide Web, most sites, be it large or small, contain a Contact Us page. The purpose of the Contact Us page is to get your clients or customers to talk to you or inquire more about your services. Ultimately, it is to generate potential business for your company. A site contact page may seem insignificant, but it is the only gateway for your visitors to get in touch with you. More often than not, the Contact Us page takes up a small fraction of the web site, it usually contains a simple form, or in some cases, a hyper linked email and contact number. No matter how simple this page seems, great care and attention should be given to where this link is to be placed, what content it should contain or the style of copy writing for that page. Subconsciously, these things tend to be overlooked. We may connect this to your database as well, if you so wish, to enable your business to utilize it.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('33', 'Professional Search engine optimization', '30', 'Search engine optimization (SEO) is the process of affecting the visibility of a website or a web page in a search engine\"s unpaid results - often referred to as \"natural,\" \"organic,\" or \"earned\" results. In general, the earlier (or higher ranked on the search results page), and more frequently a site appears in the search results list, the more visitors it will receive from the search engine\"s users. SEO may target different kinds of search, including image search, local search, video search, academic search, news search and industry-specific vertical search engines. Now standard search engine optimization from low cost SEO providers tries to sell their effort in getting you ranked as per your own given keywords. But how will you decide on your target keywords? At the most, if you are a Nursing Home owner from Kolkata, you may say, you like to have a keyword like \"best Hospital in Kolkata\". But are you sure, that most people search hospitals in kolkata, using this particular keyword? Who will advise you what was the major keyword searched for, during last month? We found many a times, that its not \"best hospital in Kolkata\" keyword, which people used the most but they looked for \"XYZ hospital\" in kolkata or so. And hence, our business consultant will advise you to use a landing page describing why your nursing home is better than \"XYZ hospital\" and how patients from that XYZ Hospitals can get more rebate for attending your own nursing home.  And we will try to get your such pages highlighted with only one target of getting customers from your competing hospitals.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('34', 'Virtual live chat agent', '30', 'This will help you to chat (like facebook chatting) with your would be customers, directly, at the time when your customer want it to be. You can also use this chat facility as an android/windows/apple app to be downloaded and used from your smartphone. So, even if you go out, you will not lose the opportunity to chat with your intended customers. You can also use it as a HINDI application from your phone or PC.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('35', 'Facebook Connectivity', '30', 'With a Facebook Page, you can easily show customers what you are all about. Keep new and existing customers engaged by: Listing details â€“ such as opening hours and contact info, Adding big, beautiful photos and images, Posting updates to let people know the latest about your business. We will create a your similar facebook page, dedicated for your business, for your customers to like it and by that way, the friends and connected people of your customers or relatives also will get to know about your business. You can thus let the message of your business spread out to a much larger crowd than you could have imagine. If you happen to own a restaurant, you can update it as frequently as you want to promote discounts or new food items amongst your facebook friendly customers and they will immediately get an update from your facebook page by way of mail, if they are connected with you.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('36', 'Twitter Connectivity', '30', 'Hundreds of millions of users are on Twitter today. These users are on Twitter to discover new things â€” your business could be one of them!
Because Twitter Ads are objective-based, they also allow you to set specific goals and only pay for results that align with those goals.

You can use Twitter Ads to:
â€¢Grow your base of relevant followers
â€¢Increase your website traffic and conversions
â€¢Increase your app downloads and engagements
â€¢Find high-quality leads
â€¢Increase your engagements on Twitter, such as likes and Retweets
â€¢Raise awareness and build excitement with video content');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('37', 'Linkedin connectivity', '30', 'Linkedin generally is used by professionally successful high income group people like NRIs, industrialists etc, besides job seekers. Its normally not being used by housewives or similar profiles. We will create a high-level overview of your business that showcases your brand in this page. We will ensure to share what makes your business unique. And will help you to start growing your follower base so your message is heard. We will be adding a Follow button to your website. We will also begin a conversation by sharing company status updates. Thereafter you can post interesting articles,company news, promotions, and more. depending on your wishes, after consulting our business consultant, you may or may not go for Linkedin based advt. as well and we will assist you to do that.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('38', 'Disaster recovery, backup and restore reporting #1', '30', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #1');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('39', 'Human Resource Recruitment or Career Page', '35', 'Needless to say, many a times, we faced the most difficult choice of getting a good manpower to assist us in our business. Most of the time, we start asking our known person(s) to get us â€œsomeoneâ€ to assist us in our business. Now this known person, is not going dead in finding out a better manpower resource for you, but will supply you â€œsomeoneâ€, from whom your known person was once benefitted. So, essentially, you will now be paying for this â€œsomeoneâ€, as the payment towards your â€œknown person\"sâ€ benefit. And this â€œsomeoneâ€ for most part of this employment, will remain more committed towards your â€œknown personâ€, rather than â€œYOUâ€ for obvious reason. Hence we will create a career page with possible active but virtual chat agent (depending on your situation) for you to control such recruitment and chat with possible candidates.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('40', 'MySQL database storage- 10MB', '36', 'This is the Major KEY for you to collect all of your visitors data, whoever has ever contacted you for anything. This has the potential to even work with them, even after 5 years, as their contacts and enquiries remain in your database forever. Our Business consultants will be able to give you more idea, about this database, during their meeting time with you, depending on your requirement.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('41', 'PERL /CGI', '36', 'Perl is a script programming language that is similar in syntax to the C language and that includes a number of popular UNIX facilities such as sed, awk, and tr. Perl is an interpreted language that can optionally be compiled just before execution into either C code or cross-platform bytecode. CGI, or Common Gateway Interface, is the standard programming interface between Web servers and external programs. It is one of the most exciting and fun areas of programming today. The CGI standard lets Web browsers pass information to programs written in any language. Our programmers will use them and you do not need to worry about how to utilize them (but get the benefit of our programmer\"s knowledge base)');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('42', 'Hosting space allowed - 500MB', '45', 'This is the Hard disk space allowed on our Ontario, Canada, datacenter server, which has (1) On-site Security - Uniformed security patrol the premises and surrounding area 24/7/365 as part of a customized security system and protocol while optical turnstiles and door entry card access provide a second level of security. (2) Load-balanced Clustered Servers - Hundreds of high performance rack mounted servers form the core of the datacenter clustered platform, working together like a super computer. Real-time load balancing across these servers ensure that websites are delivered blazing fast during extreme high load scenarios (millions of visitors per second). The servers themselves are fully hot swappable, allowing for upgrades and maintenance on-the-fly.  (3) Firewalling - Redundant firewalling ensures that websites hosted with us are not affected by denial of service attacks, spammers or any other malicious activity that would typically bring dedicated servers to a crawl. (4) Network Topology - Millions of dollars have been invested into our network and datacenter infrastructure. Our datacenter peers with every major Tier 1 network. Your website is delivered ultra-fast from anywhere in the world. (5) Power Systems - Our Data Center power system goes beyond the local power grid to guarantee maximum uptime. Auto-switched diesel power generators and UPS systems provide power conditioning and ensure uninterrupted data center operation. The generators are tested regularly to ensure normal functionality in the event of an emergency. ');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('43', 'Monthly data transfer allowed - 1GB', '45', 'This is the amount of data (1 GB = 1073741824 bytes), that your visitors are allowed to consume.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('45', 'HTML site map (not sitemap, which we will cover later) page for your visitors', '45', 'On every site, a site map is accessible to everyone, human and bots. There are all kinds of bots roaming the net. Ones for directories, ones looking for reference sites to add to their site, all kinds! You can earn some free organic links just by providing a site map. Ok not every site needs a site map to start with. If you are starting out small with 2, 3 or 4 pages a site map might be overkill at the beginning but plan for where the link will go in the future. As your site expands you can destroy the usability of your design by adding too many links to the navigation. Also too many links on a page compared to actual content can turn your pages into what looks like a link farm/spam page. For people who have accessibility challenges and those who just plain got lost on your site, a site map is a savour. They can just go to the site map to find where they want to go next on your site.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('46', 'standard favicon icon to standout your site', '45', 'Have you ever added a site to your favorites menu in modern browsers such as IE and Firefox, and noticed that a web site\"s own custom icon was added beside the site\"s title in your list? Rather than the plain default icon, this custom icon makes the site stand out from the others in the list. Now, which site are you most likely to click on when you view that list again? Probably the one with the special icon! If you have not seen one yet, you can take a look by going to sites such as Dynamicdrive.com or Pageresource.com, and adding them to your favorites list. Notice how a colored icon suddenly appears in the favorites menu, and how the icon is also added to your \"Address\" area where you type in a web site URL. So, how can you do the same thing? All that is actually required is that you create a file called favicon.ico and place it in your main website directory where the other HTML files are stored. The trick is in the creation of the icon file.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('47', 'News/products/services ticker effect #1', '45', 'We will use intuitive feature to create professional scrolling content and site content tickers to display and highlight special offers, events and releases.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('49', 'SMTP+Auto Responder', '45', 'SMTP = Simple mail transfer protocol --> This protocol is used to SEND (for receiving the protocol is POP3) mails. Auto responder means, you will get the benefit of setting up rules, to make your website send an automatic response, for some particular mails. It could be from a particular person or with a particular subject or so. This will in turn enable you to appear, to others, that you are working with a team behind you. Our business consultants will work with you to get you the maximum benefit by using this feature.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('50', 'Business promotion Planning meeting + Preparation of annual business promotion calendar', '45', 'Our business consultants will sit and work with you to devise a suitable promotion for your business. Our consultants are equipped with information related to online marketing, sales, print media marketing, Logistics, Finance and HR. So, they will be able to effectively guide you to look and work like a professionally managed company. At the end, they will come up with a properly planned calendar of events, which we will follow to get you the expected results. Its highly important that you will listen to our advice, and understand, what needs to be done from your side too, as without that activity, we may not be able to achieve our objectives.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('51', 'HR Portal for leaves and attendance', '45', 'Attendance and leaves are basic part of HR management and we try to maintain these, using our customer web portals. (Customer can also opt in for a finger printing device to manage attendance at an optional cost of INR 7500/-, which can further streamline the employees attendance. ) The portal will calculate the salary, considering leaves availed automatically. The employees themselves can also easily figure out their remaining leaves, from the portal (using any internet enabled device) or the owner can ascertain the number of the leaves due for any employee.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('52', 'High quality images for your website', '60', 'As your brand is heavily dependent on our websites, its mandatory for us to use high quality images for you.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('53', 'Professionally designed 404-not found page/', '60', '404-not found page is what the websites show up, when a visitor is arbitrarily trying to go to a web page which is not existing. To make your company look like an enterprise, we will design a 404-not found page, with your logo and a comment which is basically something to enjoy, with a link to go back to your home page or the most important page.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('54', 'HR salary calculation Page', '60', 'This is where, our client can put in individual employees salary details and can see the payment details.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('55', 'Disaster recovery, backup and restore reporting #2', '60', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #2');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('57', 'Facebook Page creation#1', '75', 'People all over the world visit Facebook to connect with friends, family and things that interest them â€“including businesses. Your customized Page can help you market your business, and is a place where customers can learn about your products and services. Customers may also see the things that you promote in News Feed â€“ the constantly updating list of stories on Facebook. And best of all, your Page is free, easy to set up and helps people find you on Facebook and the web.Keep new and existing customers engaged by:
â€¢Listing details â€“ such as opening hours and contact info
â€¢Adding big, beautiful photos and images
â€¢Posting updates to let people know the latest about your business');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('58', 'Business Consulting Meeting, planning and rescheduling calendaring of events #2', '80', 'This calendar will be resceduled after our business consultants sit with you, analyse the set goals, Google Analytics report, Google Adwords report, Facebook advert reports etc. and find out differences in expected results, from what was planned and what was acheived. And will try to get you a rescheduled objective driven plan for the rest of the year, which will be updated, next quarter, depending on how the business is running, after following his advice. All reports till then, will be analysed and a reconstructed plan will follow.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('59', 'Robots.txt file to avoid unauthorized access of search engine spiders on your site', '90', 'The robots exclusion protocol (REP), or robots.txt is a text file we will create to instruct robots (typically search engine robots, which see your site to utilize it in any unauthorized way) how to crawl and index pages on their website. It can (1) Block all web crawlers from all content (2) Block a specific web crawler from a specific folder (3) Block a specific web crawler from a specific web page.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('60', 'Website Update #1', '90', 'Your website will be revamped as per your decision, which you will be able to take, after you sit with our business consultant for the 2nd time. All other page integrations will be redone, if necessary.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('61', 'Recruitment Announcement in career Page #1', '90', 'Any new recruitment need after the second round of business consultant meeting, will be published in your website, in the career page, which will also help your site to appear more times on Internet, as it will be looked into by possible candidates. This in turn will help your website to appear heigher in the Google ranking.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('62', 'Disaster recovery, backup and restore reporting #3', '90', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #3');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('63', 'Google adwords Planning, Budgeting and Analysis #2', '97', '2nd updated Planning, Budgeting and Analysis, as we did in the first one, after consulting the Business analyst and the owner. Changes suggested will be incorporated for the next quarter.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('64', 'Facebook Advt. Planning #2', '97', '2nd Facebook advertisement planning as per the directives of the business consultant and the owner.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('65', 'Mobile responsive site creation#2', '115', '2nd version of mobile site, as envisaged by the business consultant and the client.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('66', 'Twitter update #1', '120', 'Twitter advt. update as per the business consultant and owner or decision maker\"s wishes after their second meeting.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('67', 'Linkedin Update #1', '120', 'Linkedin related activities update after second business meeting between business analyst and the owner or decision maker and as per their directives or wishes.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('68', 'Disaster recovery, backup and restore reporting #4', '120', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #4');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('69', 'Facebook Page creation#2', '125', 'Facebook Page will be updated People all over the world visit Facebook to connect with friends, family and things that interest them â€“including businesses. Your customized Page can help you market your business, and is a place where customers can learn about your products and services. Customers may also see the things that you promote in News Feed â€“ the constantly updating list of stories on Facebook. And best of all, your Page is free, easy to set up and helps people find you on Facebook and the web.Keep new and existing customers engaged by:
â€¢Listing details â€“ such as opening hours and contact info
â€¢Adding big, beautiful photos and images
â€¢Posting updates to let people know the latest about your business');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('70', 'MySQL database page update #1', '126', 'Depending on Business Consultant and Owner or Decision maker\"s decision after second business consulting meeting, the functionality of the current database may change and it may include update/edit/new page creation, using data already collected. Any Database Table addition/alteration/architecture changes will attract optional cost @INR 2500 + Applicable Taxes (Currently 14.5%)  per Table addition/alteration/architecture.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('71', 'News/products/services ticker effect #2', '135', '2nd Update: Updated News, products or services introduction or promotional announcements. These actions will be taken as per the Business Analyst and owner or decision maker\"s decision.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('72', 'Disaster recovery, backup and restore reporting #5', '150', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #5');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('73', 'Business Consulting Meeting, planning and rescheduling calendaring of events #3', '170', 'This calendar will be again rescheduled after our business consultants sit with you, analyse the set goals, Google Analytics report, Google Adwords report, Facebook advert reports etc. and find out differences in expected results, from what was planned and what was achieved. And will try to get you a rescheduled objective driven plan for the rest of the year, which will be updated, next quarter, depending on how the business is running, after following his advice. All reports till then, will be analysed and a reconstructed plan will follow.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('74', 'Website', '180', 'Depending on the Business Analyst and Client\"s decision (after Business consultant\"s second meeting), the website will have new look, new features added.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('75', 'Recruitment Announcement in career Page #2', '180', 'Depending on the Business Analyst and Client\"s decision (after Business consultant\"s second meeting), new career opportunities will be announced and published. SEO will also be done on that page to maximize business discovery value');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('76', 'Disaster recovery, backup and restore reporting #6', '180', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #6');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('77', 'Google adwords Planning, Budgeting and Analysis #3', '187', '3rd updated Planning, Budgeting and Analysis, as we did in the first one, after consulting the Business analyst and the owner. Changes suggested will be incorporated for the next quarter.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('78', 'Facebook Advt. Planning #3', '187', '3rd Facebook advertisement planning as per the directives of the business consultant and the owner.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('79', 'Mobile responsive site creation#3', '205', '3rd version of mobile site, as envisaged by the business consultant and the client.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('80', 'Twitter update #2', '210', 'Twitter advt. update as per the business consultant and owner or decision maker\"s wishes after their third meeting.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('81', 'Linkedin Update #2', '210', 'Linkedin related activities update after third business meeting between business analysit and the owner or decision maker and as per their directives or wishes.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('82', 'Disaster recovery, backup and restore reporting #7', '210', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #7');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('83', 'MySQL database page update #2', '216', 'Depending on Business Consultant and Owner or Decision maker\"s decision after third business consulting meeting, the functionality of the current database may change and it may include update/edit/new page creation, using data already collected. Any Database Table addition/alteration/architecture changes will attract optional cost @INR 2500 + Applicable Taxes (Currently 14.5%)  per Table addition/alteration/architecture.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('84', 'News/products/services ticker effect #3', '225', '3rd Update: Updated News, products or services introduction or promotional announcements. These actions will be taken as per the Business Analyst and owner or decision maker\"s decision.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('85', 'Facebook Page creation#3', '225', '3rd facebook page Updation as per the directives of business consultant and the owner or decision maker.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('86', 'Disaster recovery, backup and restore reporting #8', '240', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #8');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('87', 'Business Consulting Meeting, planning and rescheduled calendaring of events #4', '260', 'This calendar will be further rescheduled after our business consultants sit with you, analyse the set goals, Google Analytics report, Google Adwords report, Facebook advert reports etc. and find out differences in expected results, from what was planned and what was achieved. And will try to get you a rescheduled objective driven plan for the rest of the year, which will be updated, next quarter, depending on how the business is running, after following his advice. All reports till then, will be analysed and a reconstructed plan will follow.
');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('88', 'Website Update #3', '270', 'Your website will be revamped as per your decision, which you will be able to take, after you sit with our business consultant for the 3rd time. All other page integrations will be redone, if necessary.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('89', 'Recruitment Announcement in career Page #3', '270', 'Any new recruitment need after the fourth round of business consultant meeting, will be published in your website, in the career page, which will also help your site to appear more times on Internet, as it will be looked into by possible candidates. This in turn will help your website to appear higher in the Google ranking.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('90', 'Disaster recovery, backup and restore reporting #9', '270', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #9');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('92', 'Google adwords Planning, Budgeting and Analysis #4', '277', '4th updated Planning, Budgeting and Analysis, as we did in the first one, after consulting the Business analyst and the owner. Changes suggested will be incorporated for the next quarter.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('93', 'Facebook Advt. Planning #4', '277', '4th Facebook advertisement planning as per the directives of the business consultant and the owner or the decision maker.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('94', 'Mobile responsive site creation#4', '295', '4th version of mobile site, as envisaged by the business consultant and the client.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('95', 'Twitter update #3', '300', 'Twitter advt. update as per the business consultant and owner or decision makers wishes after their fourth meeting.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('96', 'Linkedin Update #3', '300', 'Linkedin related activities update after fourth business meeting between business analysit and the owner or decision maker and as per their directives or wishes.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('97', 'Disaster recovery, backup and restore reporting #10', '300', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #10');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('98', 'MySQL database page update #3', '306', 'Depending on Business Consultant and Owner or Decision makers decision after fourth business consulting meeting, the functionality of the current database may change and it may include update/edit/new page creation, using data already collected. Any Database Table addition/alteration/architecture changes will attract optional cost @INR 2500 + Applicable Taxes (Currently 14.5%)  per Table addition/alteration/architecture.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('99', 'News/products/services ticker effect #4', '315', '4th Update: Updated News, products or services introduction or promotional announcements. These actions will be taken as per the Business Analyst and owner or decision makers decision.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('100', 'Renewal of contract', '315', 'This is the last date, by which you have to pay the renewal fees, to renew these services for your business.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('101', 'Disaster recovery, backup and restore reporting #11', '330', 'Disaster, Backup and restore operation for website, MySQL database and portal reporting will be made with details of failed times, if any. #11');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('102', 'One site upto 20 page creation', '21', 'We define our website related work as WebSite Engineering, rather Website Development, as we directly connect this effort with our marketing and sales effort for our clients. Its not simply a \"nice to have\" stuff, rather we wish to make it a \"must have\" stuff. This ideally should describe your Products or Services in details, including your sales process. We like you to direct all of your sales and marketing work, as if YOU are doing it. All of the automated work here will be done as if YOU are doing it, to give it the maximum importance. And these pages will also include professionally designed Search Engine Optimized pages (which means, each of the pages will have different descriptions, keywords like meta data) and Business Consultant proposed landing pages as per SEO requirements. For example, if you have a Gold Jewellery shop, our consultants will collect data from Google about \"what is searched mostly in your industry, last month\" and not go by common intuition that people searched only for \"best Jewellery shop\" like phrase. We found that people looked for \"XYZ Jewellery shop\" more and hence, we suggested that your business should have a landing page from google adwords, comparing why people should buy from you, rather than \"XYZ jewellery shop\" with possible rebate in your \"making charge\" component, using unique code, generated by our server.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('103', 'External vendor Connectivity(Amazon,Flipkart,Snapdeal,ebay etc.)', '40', 'These things will depend on the outcome of your business consulting meeting with our consultants. If its found that you can use these connections to improve your revenues, our consultants will assist you to get involved in these ecommerce vendor sites.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('105', 'XML sitemap page creation and submission of XML sitemap to major search engines ', '75', 'A sitemap is a file where we can list the web pages of your site to tell Google and other search engines about the organization of your site content. Search engine web crawlers like Googlebot read this file to more intelligently crawl your site. Also, our sitemap can provide valuable metadata associated with the pages we list in that sitemap: Metadata is information about a webpage, such as when the page was last updated, how often the page is changed, and the importance of the page relative to other URLs in the site. We can use a sitemap to provide Google with metadata about specific types of content on your website pages, including video, image, and mobile content. For example, we can give Google the information about video and image content:
â€¢A sitemap video entry can specify the video running time, category, and age appropriateness rating.
â€¢A sitemap image entry can include the image subject matter, type, and license.');
insert into `line_up_items` (`id`, `item_name`, `req_days`, `item_description`) values ('106', 'Fully functional contact-us form,feedback from,Registration form,Support form etc. ', '45', 'Most business owners will tell you that one of their goals is to obtain more customers in order to make more money.  Since more and more people are researching and shopping online, your website must provide a way for potential and current customers to contact you. Here are five best practices for contact forms. Have a contact form on your website under Contact Us. The majority of users expect to see a Contact Us page on your website.  We will create a quick and easy form for them to contact you.  The more fields and the more required fields you have, your customers will turn them off. So we will keep it simple. Another great idea is to have quick contact forms on ALL pages of your website.  We will make it as easy as possible for the customers to contact you.  Above is our quick contact form.  We will also create Auto Respond within 24 hours - Todayâ€™s world moves at a faster pace than it did 10 years ago or even 5 years ago.  This is the age of instant gratification.  If you want the business, you need to be ready to respond quickly.  If you donâ€™t, your competitor might. Maybe you are a one-person office.  We will set up an auto response for every contact form submission that gives an estimated time for reply.  Maybe you say they can expect a reply within 24-72 hours.  Just make sure to respond during that time frame. 
Do you know if your contact form is working?  We will check it ourselves.  We will set up a routine of completing the form once a month and make sure you (or the intended email recipient) receives it.  Contact forms that go into the internetâ€™s blackhole will never become your customers. And you will get a report form us about that. Finally more Than Forms - In today age, there are multiple generations shopping.  Baby Boomers, Gen X, and Gen Y make up the largest percentage.  Each likes to shop and interact differently.  Along with a contact form we will consider adding - Your telephone number, Your address, Your email address, A phone number the customer can text and Your social media links. We will provide potential and current customers as many ways as possible to contact you.  Then you better be sure that you are checking and responding in a timely manner.');
 
drop table if exists `phpjobscheduler`; 
CREATE TABLE `phpjobscheduler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scriptpath` varchar(255) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT '0',
  `time_last_fired` int(11) DEFAULT NULL,
  `run_only_once` tinyint(1) NOT NULL DEFAULT '0',
  `currently_running` tinyint(1) NOT NULL DEFAULT '0',
  `paused` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fire_time` (`fire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
insert into `phpjobscheduler` (`id`, `scriptpath`, `name`, `time_interval`, `fire_time`, `time_last_fired`, `run_only_once`, `currently_running`, `paused`) values ('5', 'http://hctrnd.com/phpmysqlautobackup/run.php', 'Backup Db', '1800', '1448268008', '0', '0', '0', '0');
 
drop table if exists `phpjobscheduler_logs`; 
CREATE TABLE `phpjobscheduler_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_added` int(11) DEFAULT NULL,
  `script` varchar(128) DEFAULT NULL,
  `output` text,
  `execution_time` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `phpjobscheduler_logs` (`id`, `date_added`, `script`, `output`, `execution_time`) values ('1', '1447072504', 'http://hctrnd.com/phpmysqlautobackup/run.php', '', '127.66990 seconds via PHP CURL ');
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1449207928');
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447134783', '30604', '143');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1447307275', '30386', '126');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1448014613', '36317', '141');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1448014772', '36318', '141');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1448266183', '54766', '160');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1448543025', '87023', '234');
 
drop table if exists `s_chat_messages`; 
CREATE TABLE `s_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `m_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('1', 'User1', 'hello', '1446118711');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('2', 'User2', 'hello...ki kobor?', '1446118783');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('3', 'User1', 'ei to cholche.. vai..', '1446118801');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('4', 'User2', 'popyeye er ki kobor?', '1446118874');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('5', 'User1', 'jiges kor ki bolche..', '1446118912');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('6', 'User3', 'hello', '1446118964');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('7', 'User3', 'hello sir', '1446118981');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('8', 'User2', 'hello...', '1446118990');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('9', 'User1', 'j jar nam ta plz bol.', '1446119004');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('10', 'User1', 'chandrakanta ki korchis/', '1446122467');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('11', 'User2', 'ki aar korbo?', '1446122514');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('12', 'User1', 'Kano kono kaj nei?', '1446122533');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('13', 'User2', 'excel korchi...', '1446122561');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('14', 'User2', 'excel korchi...', '1446124319');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('15', 'Chandrakanta', 'hello....', '1446190855');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('16', 'Krishanu', 'Ki korchis sobai?', '1446190905');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('17', 'Debashis', 'hi everybody..', '1446190909');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('18', 'Krishanu', 'Sobai ki korche?', '1446190977');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('19', 'Krishanu', 'hi', '1446191089');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('20', 'Krishanu', 'Hello', '1446191397');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('21', 'User1', 'Ki korchis sobai?', '1446191510');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('22', 'User1', '123', '1446191578');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('23', 'User1', '123', '1446191768');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('24', 'User1', 'kemon acho...bondhu?', '1446191906');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('25', 'Krishanu', 'Hi chandra', '1446192351');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('26', 'Chandrakanta', 'hello bhai...ki kobor?', '1446192370');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('27', 'Krishanu', 'ei badge print korte hobe..', '1446192388');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('28', 'Chandrakanta', 'kore phel...', '1446192430');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('29', 'Krishanu', 'sei to.', '1446192493');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('30', 'Debashis', 'bhalo aco sobai', '1446192706');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('31', 'Debashis', 'time not correct..pls check..', '1446192753');
insert into `s_chat_messages` (`id`, `user`, `message`, `m_time`) values ('32', 'Krishanu', 'okay', '1446196174');
 
drop table if exists `supplier_details`; 
CREATE TABLE `supplier_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('1', 'Krishanu Acharya', 'Barasat', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('2', 'Arindam Pal', 'FA-50 rajdanga road, near ruby, kolkata-700107', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('3', '', '', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('5', 'Arindam Pal', 'Barasat', '3');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('6', 'rtyrete', 'retert56 erye', '4');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('7', '', '', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('8', 'Arindam Pal', 'kolkata', '1');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('9', '', '', '5');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('10', '', '', '5');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('19', 'Krishanu Acharya', 'FA-50 rajdanga road, near ruby, kolkata-700107', '15');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('20', 'etrerytr', 'ryeryreyreyery', '26');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('23', 'Arindam Pal', 'kolkata', '15');
insert into `supplier_details` (`id`, `name`, `address`, `company_id`) values ('24', '', '', '29');
 
drop table if exists `templateadd`; 
CREATE TABLE `templateadd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vrt_type` varchar(255) NOT NULL,
  `sourcefile` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('1', 'Hospitals and Nursing Home', 'vertical_template/Hospitals and Nursing Home/hospitals_and_nursing_home1/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('2', 'Hospitals and Nursing Home', 'vertical_template/Hospitals and Nursing Home/hospitals_and_nursing_home2/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('3', 'Hotel', 'vertical_template/Hotel/hotel1/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('4', 'Hotel', 'vertical_template/Hotel/hotel2/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('5', 'Garment Shop', 'vertical_template/Garment Shop/garment_shop1/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('6', 'Garment Shop', 'vertical_template/Garment Shop/garment_shop2/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('7', 'Restaurant', 'vertical_template/Restaurant/restaurant1/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('8', 'Tours and travel', 'vertical_template/Tours and travel/tours_and_travel1/');
insert into `templateadd` (`id`, `vrt_type`, `sourcefile`) values ('9', 'Jewellery Shop', 'vertical_template/Jewellery Shop/jewellery_shop1/');

ALTER TABLE `bank_detail` ADD   CONSTRAINT `bank_detail_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `business_details` ADD   CONSTRAINT `business_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `company_sells` ADD   CONSTRAINT `company_sells_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `connections` ADD   CONSTRAINT `connections_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `customer_details` ADD   CONSTRAINT `customer_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);

ALTER TABLE `supplier_details` ADD   CONSTRAINT `supplier_details_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company_details` (`ID`);
