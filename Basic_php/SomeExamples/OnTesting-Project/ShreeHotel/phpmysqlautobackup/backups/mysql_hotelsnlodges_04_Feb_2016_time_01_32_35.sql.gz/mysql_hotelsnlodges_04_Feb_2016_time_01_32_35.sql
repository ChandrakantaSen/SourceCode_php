# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: hotelsnlodges
# Domain name: kahinihoteldigha.com
# (c)2016 kahinihoteldigha.com
#
# Backup START time: 01:32:35
# Backup END time: 01:32:35
# Backup Date: 04 Feb 2016
 
drop table if exists `booking_details`; 
CREATE TABLE `booking_details` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `c_id` int(20) NOT NULL,
  `room_number` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `room_type` varchar(500) NOT NULL,
  `rate` int(50) NOT NULL,
  `total_price` int(11) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
insert into `booking_details` (`id`, `c_id`, `room_number`, `room_type`, `rate`, `total_price`, `check_in`, `check_out`, `status`) values ('1', '1', '101', 'Standard Double Bedroom(Non AC)', '850', '2550', '2016-02-02', '2016-02-04', 'Cancel');
insert into `booking_details` (`id`, `c_id`, `room_number`, `room_type`, `rate`, `total_price`, `check_in`, `check_out`, `status`) values ('2', '2', '101', 'Standard Double Bedroom(Non AC)', '850', '2550', '2016-02-27', '2016-03-01', 'Cancel');
insert into `booking_details` (`id`, `c_id`, `room_number`, `room_type`, `rate`, `total_price`, `check_in`, `check_out`, `status`) values ('3', '3', '201', 'Standard four bedded bedroom(Non AC)', '1350', '4050', '2016-02-27', '2016-03-01', 'Cancel');
insert into `booking_details` (`id`, `c_id`, `room_number`, `room_type`, `rate`, `total_price`, `check_in`, `check_out`, `status`) values ('4', '4', '209', 'Deluxe Double Bedroom(AC)', '1350', '2700', '2016-02-27', '2016-02-29', 'Booked');
insert into `booking_details` (`id`, `c_id`, `room_number`, `room_type`, `rate`, `total_price`, `check_in`, `check_out`, `status`) values ('5', '5', '101', 'Standard Double Bedroom(Non AC)', '850', '1700', '2016-02-03', '2016-02-04', 'Booked');
 
drop table if exists `contact`; 
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `contact_date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
insert into `contact` (`id`, `name`, `phone`, `email`, `subject`, `comments`, `contact_date`) values ('10', 'Debashis Sahoo', 'd.sahoo@hexcodetechnologies.com', '9804254250', 'Feedback', 'nice hotel in digha..', '1454330084');
insert into `contact` (`id`, `name`, `phone`, `email`, `subject`, `comments`, `contact_date`) values ('11', 'Debashis Sahoo', 'info@hexcodetechnologies.com', '9804254250', 'Suggestion', 'nice trip', '1454331447');
 
drop table if exists `message`; 
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1454567555');
 
drop table if exists `room_details`; 
CREATE TABLE `room_details` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `room_number` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('3', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '101');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('6', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '102');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('7', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '103');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('8', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '104');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('9', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '105');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('10', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '106');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('11', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '107');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('12', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '108');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('13', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '109');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('14', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '110');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('15', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '111');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('16', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '112');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('17', 'Standard Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '850', '113');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('18', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '202');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('19', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '203');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('20', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '204');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('21', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '205');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('22', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '206');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('23', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '208');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('24', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '210');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('25', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '302');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('26', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '303');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('27', 'Deluxe Double Bedroom(Non AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '950', '304');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('28', 'Standard four bedded bedroom(Non AC)', 'Max. 4 adults & 2 child/ Max. 5 adults', '1350', '201');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('29', 'Standard Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1150', '207');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('30', 'Standard Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1150', '308');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('31', 'Deluxe Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1350', '209');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('32', 'Deluxe Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1350', '305');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('33', 'Deluxe Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1350', '306');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('34', 'Deluxe Double Bedroom(AC)', 'Max. 2 adults & 2 child/ Max. 3 adults', '1350', '307');
insert into `room_details` (`id`, `name`, `description`, `price`, `room_number`) values ('37', 'Standard four bedded bedroom(AC)', 'Max. 4 adults & 2 child/ Max. 5 adults', '1750', '301');
 
drop table if exists `tbl_admin`; 
CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `tbl_admin` (`id`, `username`, `password`) values ('1', 'admin', '1234');
 
drop table if exists `visitor_details`; 
CREATE TABLE `visitor_details` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
insert into `visitor_details` (`id`, `name`, `address`, `contact`, `email`) values ('1', 'Debashis Sahoo', 'digha', '9804254250', 'd.sahoo@hexcodetechnologies.com');
insert into `visitor_details` (`id`, `name`, `address`, `contact`, `email`) values ('2', '', '', '', '');
insert into `visitor_details` (`id`, `name`, `address`, `contact`, `email`) values ('3', '', '', '', '');
insert into `visitor_details` (`id`, `name`, `address`, `contact`, `email`) values ('4', 'Amaresh', 'Shyamnagar', '123456789', 'amaresh@gmail.com');
insert into `visitor_details` (`id`, `name`, `address`, `contact`, `email`) values ('5', 'Debashis Sahoo', 'digha', '9804254250', 'd.sahoo@hexcodetechnologies.com');
