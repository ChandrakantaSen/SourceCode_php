<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
  
$("#category").change(function()
{
var dataString = 'id='+ $(this).val();
$.ajax
({
type: "POST",
url: "view2.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bed").html(html);
} 
});
});

$("#bed").change(function()
{
var dataString = 'id1='+ $(this).val();
$.ajax
({
type: "POST",
url: "view3.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bedc").html(html);

} 

});
});


$("#bed").change(function()
{
var dataString = 'id2='+ $(this).val();
$.ajax
({
type: "POST",
url: "view4.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bedf").html(html);

} 
});
});


});

</script>
</head>
<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
$sql="select category from hsptl_details group by category";
$retval=mysqli_query($conn, $sql);
?>
<body>
<form action="" method="POST">
<table border="1">
<tr>
<td>
<table>
	<tr><td>Patient I.D. No.</td><td><input type="text" name="patient_id"></td><td>Admission Date</td><td><input type="date" name="admsn_date">Time<input type="time" name="admsn_time"></td></tr>

	<tr><td><b>Patient Details</b></td><td colspan="3"></td></tr>
	<tr><td>Patient Name</td><td><input type="text" name="patient_name"></td><td>Age</td><td><input type="text" name="age"><select><option>Year</option></select></td>
	<tr><td><input type="radio" name="so" value="so"> S/o<input type="radio" name="do" value="do"> D/o<input type="radio" name="wo" value="wo"> W/o</td><td><input type="text" name="father_name"></td><td>Sex</td><td><select name="sex"><option value="Male">Male</option><option value="Female">Female</option></select></td></tr>
	<tr><td>Address</td><td><textarea name="p_address" cols="30" rows="3"></textarea></td><td>Religion<br>Occupation<br>Phone No.</td><td><input type="text" name="religion"><br><input type="text" name="occupation"><br><input type="text" name="phone_no"></td></tr>
	<tr><td><b>Admitted By</b></td><td colspan="3"></td></tr>
	<tr><td>Name</td><td><input type="text" name="admitter_name"></td><td>Phone No.</td><td><input type="text" name="a_phn"></td></tr>
	<tr><td>Address</td><td><textarea cols="30" rows="2"></textarea></td><td>Relation</td><td><input type="text" name="a_relation"></td></tr>
	<tr><td>Veg/Non Veg</td><td>
		<select>
			<option>
				---Select Meal---
			</option>
			<option value="Veg">
				Veg
			</option>
			<option value="Non Veg">
				Non Veg
			</option>
		</select>
	</td><td colspan="2">Reference Doctor<br>
	<select name="r_doctor">
		<option>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
		</option>
	</select>
	</td></tr>
	<tr><td>Patient Status</td><td>
		<select>
			<option>
				Patient Status
			</option>
		</select>
	</td><td><input type="checkbox" name="">Corporate/TPA</td></tr>
	<tr><td>VIP/Reference</td>
	<td>
		<select>
			<option>----Select----</option>
			<option value="VIP">VIP</option>
			<option value="Reference">Reference</option>
		</select>
	</td><td><select><option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option></select></td></tr>
	<tr>
	<td>Marketing Exe.</td><td><select><option></option></select></td><td>Policy No. </td><td><input type="text" name="policy_no"></td></tr>
	<tr><td>Agency Name</td><td><select><option></option></select></td><td>Membership No.</td><td><input type="text" name="agncy_name"></td></tr>
	<tr><td></td><td></td><td colspan="2"><button style="width: 100px;">Add</button><button style="width: 100px;">Save</button></td></tr>
	<tr><td></td><td></td><td colspan="2"><button style="width: 100px;">Cancel</button><button style="width: 100px;">Remove</button></td></tr>
	<tr><td>Assign Doctor</td><td><select><option></option></select></td><td>Grade</td><td><select><option></option></select></td></tr>
	<tr><td>Department</td><td><select><option></option></select></td><td>Package</td><td><input type="checkbox"><select><option></option></select></td></tr>
</table>
</td>
<td>
<table>
	<tr><td><b>Registration</b></td></tr>
	<tr><td><input type="radio">Existing</input></td><td><input type="radio">New</input></td></tr>
	<tr><td colspan="2"><center><input type="text"></center></input></td></tr>
	<tr><td colspan="2"><center><input type="checkbox">Advance Booking</input></center></td></tr>
	<tr><td colspan="2"><center><select><option></option></select></center></td></tr>
	<tr><td colspan="2"><center><button style="width: 100px;">New</button><button style="width: 100px;">Save</button></center></td></tr>
	<tr><td colspan="2"><center><button style="width: 100px;">Search</button><button style="width: 100px;">Close</button></center></td></tr>
	<tr><td colspan="2"><center><button style="width: 50px;"><<</button><button style="width: 50px;"><</button><button style="width: 50px;">></button><button style="width: 50px;">>></button></center></td></tr>
	<tr><td colspan="2"><center><button>Registration Form</button></center></td></tr>
	<tr><td colspan="2"><br><br></td></tr>
	
    
    <tr><td>Select Category</td>
  <td>
  <select id = "category" name="category">
  <option>--Select Category--</option>
    <?php
      while($row=mysqli_fetch_assoc($retval))
      {
        echo "<option value='$row[category]'>$row[category]</option>";
      }
    ?>
  </select>
  </td>
  </tr>
  <tr><td>Select Bed NO.</td>
  <td>
  <select id = "bed" name="bed">
    <option>--Select Bed--</option>
  </select>
  </td>
  </tr>
  <tr><td>Bed Charge<br> Floor<br></td><td>
  <select id="bedc" name="bedc"><option >------------</option></select><br><select id="bedf" name="bedf"><option >------------</option></select>
  </td>
  </tr>
  <tr><td colspan="2"><br><br></td></tr>

	<tr><td>Package Charge</td><td>Day</td></tr>
	<tr><td><input type="text"></input></td><td><input type="text"></input></td></tr>
    <tr><td colspan="2"><center>Date Of Procedure</center></td></tr>
	<tr><td colspan="2"><center><input type="date"></center></input></td></tr>
</table>
</td>
</tr>
</table>
</form>
</body>
</html>