<b>Bed Transfer Details</b>
<br>
<br>
<!DOCTYPE html>
<html>
<head>
	<title>Bed Transfer</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
  
$("#p_id").change(function()
{
var dataString = 'id='+ $(this).val();
$.ajax
({
type: "POST",
url: "bchange_1.php",
data: dataString,
cache: false,
success: function(html)
{
$("#p_name").html(html);
} 
});
});

$("#p_id").change(function()
{
var dataString = 'id1='+ $(this).val();
$.ajax
({
type: "POST",
url: "bchange_2.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bed_no").html(html);
} 
});
});
$("#p_id").change(function()
{
var dataString = 'id1='+ $(this).val();
$.ajax
({
type: "POST",
url: "bchange_3.php",
data: dataString,
cache: false,
success: function(html)
{
$("#booking_date").html(html);
} 
});
});
$("#p_id").change(function()
{
var dataString = 'id1='+ $(this).val();
$.ajax
({
type: "POST",
url: "bchange_4.php",
data: dataString,
cache: false,
success: function(html)
{
$("#booking_time").html(html);
} 
});
});

$("#category").change(function()
{
var dataString = 'id='+ $(this).val();
$.ajax
({
type: "POST",
url: "view2.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bed").html(html);
} 
});
});
$("#bed").change(function()
{
var dataString = 'id1='+ $(this).val();
$.ajax
({
type: "POST",
url: "view3.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bedc").html(html);

} 

});
});


$("#bed").change(function()
{
var dataString = 'id2='+ $(this).val();
$.ajax
({
type: "POST",
url: "view4.php",
data: dataString,
cache: false,
success: function(html)
{
$("#bedf").html(html);

} 
});
});


});

</script>
</head>
<body>
<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
$sql1="select * from booking_details where status='Booked'";
$retval1=mysqli_query($conn, $sql1);
?>

<form action="" method="POST">
<table border="1">
<tr>
<td>
	<table border="0">
		<tr>
			<td>Transfer No.</td><td><input type="text" name="transfer_no"></td>
		</tr>
		<tr>
			<td>Patient I.D. No.</td><td><select name="p_id" id="p_id">
               <option>--Select ID--</option>
                   <?php
                       while($row1=mysqli_fetch_assoc($retval1))
                       {
                        echo "<option value='$row1[patient_id]'>$row1[patient_id]</option>";
                       }
                   ?>
			</select></td>
		</tr>
		<tr>
			<td>Patient Name</td><td>
              <select name="p_name" id="p_name">
               <option>---------</option>
              </select>
			</td>
		</tr>
		<tr>
			<td>Bed No.</td><td>
			  <select name="bed_no" id="bed_no">
               <option>---------</option>
              </select>
			</td>
			</td>
		</tr>
		<tr>
			<td>Date of Admission/<br>Last Shifting</td><td>
			  <select name="booking_date" id="booking_date">
               <option>---------</option>
              </select>
			</td><td>Time of Admission/<br>Last Shifting</td>
			<td>
				<select name="booking_time" id="booking_time">
                <option>---------</option>
                </select>
			</td>
		</tr>
		<tr>
			<td>Date of Shifting</td><td><input type="date" name="shft_date"></td><td>Time of Shifting</td><td><input type="time" name="shft_time"></td>
		</tr>
		<tr>
			<td>New Bed Category</td><td>
			<select name="category" id="category">
			<option>--Select Category--</option>
				<?php
				 $sql2="select category from hsptl_details group by category";
                 $retval2=mysqli_query($conn, $sql2);
                 while($row2=mysqli_fetch_assoc($retval2))
                   {
                     echo "<option value='$row2[category]'>$row2[category]</option>";
                   }
                ?>
			</select> </td><td>Select New Bed</td><td>
			<select name="bed" id="bed">
			<option>--Select Bed--</option>
			</select>
			</td><td>Floor 
               <select name="bedf" id="bedf">
			   <option>-Floor-</option>
			   </select>
			</td>
			<td>
				Bed Charge
				<select name="bedc" id="bedc">
			    <option>-Charge-</option>
			    </select>
			</td>
		</tr>
		
	</table>
</td>
</tr>
</table>	

</form>
</body>
</html>