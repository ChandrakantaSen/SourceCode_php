<?php 
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
if($_POST['id1'])
{
$id=$_POST['id1'];

$sql2=mysqli_query($conn,"select * from booking_details where patient_id='$id' and status='Booked' ");
$retval2=mysqli_query($conn, $sql2);
$row2=mysqli_fetch_array($sql2);

echo "<option value='$row[booking_date]'>$row2[booking_date]</option>";

}
?>