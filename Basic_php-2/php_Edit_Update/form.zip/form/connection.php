<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
?>