-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2016 at 01:01 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hsptl`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `id` int(50) NOT NULL,
  `category` varchar(20) DEFAULT NULL,
  `booking_date` varchar(50) DEFAULT NULL,
  `bed_c` varchar(20) DEFAULT NULL,
  `bed_f` varchar(20) DEFAULT NULL,
  `bed_no` varchar(20) DEFAULT NULL,
  `patient_name` varchar(40) DEFAULT NULL,
  `status` varchar(29) DEFAULT NULL,
  `patient_id` varchar(20) DEFAULT NULL,
  `booking_time` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking_details`
--

INSERT INTO `booking_details` (`id`, `category`, `booking_date`, `bed_c`, `bed_f`, `bed_no`, `patient_name`, `status`, `patient_id`, `booking_time`) VALUES
(1, 'General', '31-03-2016', '175', 'Ground', '150', 'ABC', 'Available', '2', '05.28 PM'),
(2, 'General', '31-03-2016', '175', 'Ground', '150', 'ABC', 'Available', '2', '05.28 PM'),
(3, 'General', '31-03-2016', '175', 'Ground', '150', 'ABC', 'Available', '2', '05.28 PM'),
(30, 'General', '31-03-2016', '600', 'Ground', '777', 'ABC', 'Available', '2', '05.28 PM'),
(31, 'General', '31-03-2016', '600', 'Ground', '777', 'Kamal Gupta', 'Available', '1', '05.28 PM'),
(32, 'ICU', '31-03-2016', '50', 'Second', '99', 'Kamal Gupta', 'Available', '1', '05.28 PM'),
(33, 'General', '31-03-2016', '200.50', 'First', '12', 'Kamal Gupta', 'Booked', '1', '05.28 PM'),
(34, 'ICU', '02-04-2016', '50', 'Second', '99', 'ABC', 'Booked', '2', '11.48 AM'),
(35, 'ICU', '02-04-2016', '600', 'First', '555', 'Swarup Das', 'Booked', '3', '1.20PM');

-- --------------------------------------------------------

--
-- Table structure for table `hsptl_details`
--

CREATE TABLE `hsptl_details` (
  `id` int(20) NOT NULL,
  `category` varchar(20) DEFAULT NULL,
  `bed_no` int(20) DEFAULT NULL,
  `bed_charge` varchar(20) DEFAULT NULL,
  `floor` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hsptl_details`
--

INSERT INTO `hsptl_details` (`id`, `category`, `bed_no`, `bed_charge`, `floor`, `status`) VALUES
(1, 'ICU', 5, '200.50', 'First', 'Available'),
(2, 'General', 150, '175', 'Ground', 'Available'),
(3, 'General', 12, '200.50', 'First', 'Booked'),
(7, 'ICU', 33, '212.75', 'First', 'Available'),
(9, 'General', 777, '600', 'Ground', 'Available'),
(10, 'ICU', 99, '50', 'Second', 'Booked'),
(11, 'ICU', 89, '225', 'First', 'Available'),
(12, 'ICU', 555, '600', 'First', 'Booked'),
(19, 'General', 111, '120', 'Ground', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`p_id`, `p_name`) VALUES
(1, 'Kamal Gupta');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_details`
--
ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hsptl_details`
--
ALTER TABLE `hsptl_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_details`
--
ALTER TABLE `booking_details`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `hsptl_details`
--
ALTER TABLE `hsptl_details`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
