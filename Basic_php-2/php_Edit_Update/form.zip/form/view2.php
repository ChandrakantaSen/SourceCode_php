<?php 
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
if($_POST['id'])
{
$id=$_POST['id'];

$sql=mysqli_query($conn,"select bed_no from hsptl_details where  category='$id' and status='Available' ");
echo "<option>--Select Bed --</option>";
while($row=mysqli_fetch_array($sql))
{
echo "<option value='$row[bed_no]'>$row[bed_no]</option>";
}

}
?>