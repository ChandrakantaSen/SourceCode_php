<?php 
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
if($_POST['id2'])
{
$id2=$_POST['id2'];

$sql=mysqli_query($conn,"select * from hsptl_details where  bed_no='$id2'");

$row=mysqli_fetch_array($sql);

echo "<option value='$row[floor]'>$row[floor]</option>";

}
?>