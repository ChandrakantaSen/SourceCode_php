<?php 
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$db='hsptl';
$conn= mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $db);
if($_POST['id1'])
{
$id1=$_POST['id1'];

$sql=mysqli_query($conn,"select * from hsptl_details where  bed_no='$id1'");

$row=mysqli_fetch_array($sql);

echo "<option value='$row[bed_charge]'>$row[bed_charge]</option>";
//echo "<input type='text' value='$row[bed_charge]'";

}
?>